# 🚀 NagarSeva — Vercel Deployment Guide

## ✅ Pre-flight Checklist (Do this FIRST)

### Step 1: Set Up Free PostgreSQL Database

**Option A — Neon (Recommended, free)**
1. Go to https://neon.tech → Sign up → Create project named `nagarseva`
2. Copy the connection string (looks like: `postgresql://user:pass@host/nagarseva?sslmode=require`)
3. Click **SQL Editor** → paste entire contents of `sql/schema.sql` → Run

**Option B — Supabase (also free)**
1. Go to https://supabase.com → New project
2. Settings → Database → copy Connection string (URI)
3. SQL Editor → paste `sql/schema.sql` → Run

---

### Step 2: Push to GitHub

```bash
# Create a new GitHub repo (do NOT initialize with README)
git init
git add .
git commit -m "Initial NagarSeva deployment"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/nagarseva.git
git push -u origin main
```

---

### Step 3: Deploy to Vercel

1. Go to https://vercel.com → **New Project**
2. Import your GitHub repo
3. Framework: **Next.js** (auto-detected) — leave all build settings as-is
4. Click **Environment Variables** and add ALL of these:

| Variable | Value | Notes |
|----------|-------|-------|
| `DATABASE_URL` | `postgresql://...` | From Neon/Supabase ✅ REQUIRED |
| `JWT_SECRET` | Random 32+ char string | Generate: `openssl rand -hex 32` ✅ REQUIRED |
| `NEXT_PUBLIC_APP_URL` | `https://your-app.vercel.app` | Your Vercel URL ✅ REQUIRED |
| `SMTP_HOST` | `smtp.gmail.com` | For OTP emails |
| `SMTP_PORT` | `587` | |
| `SMTP_USER` | `your@gmail.com` | Gmail with App Password |
| `SMTP_PASS` | 16-char app password | Gmail → Security → App Passwords |

5. Click **Deploy**

> ⚠️ Without `DATABASE_URL`, pages load but login/issues won't work.
> Without `SMTP_USER`, OTPs print to Vercel logs (check Function Logs in dashboard).

---

### Step 4: Make Yourself Admin

After deployment, go to Neon/Supabase SQL Editor and run:
```sql
UPDATE users SET role = 'admin' WHERE email = 'your@email.com';
```

---

## 🔧 Local Development

```bash
npm install
cp .env.example .env.local
# Fill in .env.local with your values

# Run DB schema (if using local postgres):
psql $DATABASE_URL < sql/schema.sql

npm run dev
# → http://localhost:3000
```

**In dev mode, OTPs print to terminal** — no SMTP needed.

---

## ❌ Common 404 Causes & Fixes

| Error | Fix |
|-------|-----|
| 404 on `/` | Missing env vars causing build fail → Add `DATABASE_URL` in Vercel |
| 500 on login | Database not seeded → Run `sql/schema.sql` |
| OTP not arriving | No SMTP set → Check Vercel Function Logs for the OTP code |
| Can't see admin tab | Run the SQL above to set your role |
