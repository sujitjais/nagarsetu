// pages/index.js — NagarSeva Complete Single-Page Application
import { useState, useEffect, useRef, useCallback } from 'react';
import Head from 'next/head';

// ─── CONSTANTS ───────────────────────────────────────────────────
const CATEGORIES = [
  { id: 'roads',    label: 'Roads & Potholes',   icon: '🚗', color: '#F97316', dept: 'ROADS'   },
  { id: 'water',    label: 'Water Leakage',       icon: '💧', color: '#3B82F6', dept: 'WATER'   },
  { id: 'lighting', label: 'Street Lighting',     icon: '💡', color: '#F59E0B', dept: 'LIGHT'   },
  { id: 'drainage', label: 'Drainage & Flooding', icon: '🌊', color: '#06B6D4', dept: 'DRAIN'   },
  { id: 'waste',    label: 'Waste & Sanitation',  icon: '🗑️', color: '#8B5CF6', dept: 'WASTE'   },
  { id: 'parks',    label: 'Parks & Trees',       icon: '🌳', color: '#16A34A', dept: 'PARKS'   },
  { id: 'other',    label: 'Other Issues',        icon: '🔧', color: '#64748B', dept: 'GENERAL' },
];

const SEVERITIES = [
  { id: 'low',      label: 'Low',      desc: 'Minor inconvenience',  color: '#16A34A', bg: '#EDFDF5' },
  { id: 'medium',   label: 'Medium',   desc: 'Daily disruption',     color: '#D97706', bg: '#FFFBEB' },
  { id: 'high',     label: 'High',     desc: 'Safety hazard',        color: '#EA580C', bg: '#FFF3EA' },
  { id: 'critical', label: 'Critical', desc: 'Emergency',            color: '#DC2626', bg: '#FEF2F2' },
];

const STATUS_CONFIG = {
  open:        { label: 'Open',         bg: '#FEF2F2', color: '#DC2626' },
  verified:    { label: 'Verified',     bg: '#EEF3FF', color: '#1A4FBF' },
  assigned:    { label: 'Assigned',     bg: '#FFFBEB', color: '#D97706' },
  in_progress: { label: 'In Progress',  bg: '#FFF3EA', color: '#EA580C' },
  resolved:    { label: 'Resolved ✓',   bg: '#EDFDF5', color: '#16A34A' },
  rejected:    { label: 'Rejected',     bg: '#F1F5F9', color: '#94A3B8' },
  duplicate:   { label: 'Duplicate',    bg: '#F5F3FF', color: '#7C3AED' },
};

// ─── API HELPER ──────────────────────────────────────────────────
async function api(path, options = {}) {
  const res = await fetch(path, {
    headers: { 'Content-Type': 'application/json', ...options.headers },
    credentials: 'include',
    ...options,
    body: options.body ? (typeof options.body === 'string' ? options.body : JSON.stringify(options.body)) : undefined,
  });
  const data = await res.json();
  if (!res.ok) throw new Error(data.error || 'Request failed');
  return data;
}

// ─── TOAST HOOK ──────────────────────────────────────────────────
function useToast() {
  const [toasts, setToasts] = useState([]);
  const show = useCallback((message, type = 'success') => {
    const id = Date.now();
    setToasts(t => [...t, { id, message, type }]);
    setTimeout(() => setToasts(t => t.filter(x => x.id !== id)), 4000);
  }, []);
  return { toasts, show };
}

// ─── MAIN COMPONENT ──────────────────────────────────────────────
export default function NagarSeva() {
  const [user, setUser]       = useState(null);
  const [view, setView]       = useState('citizen'); // citizen | admin
  const [authOpen, setAuthOpen] = useState(false);
  const [issues, setIssues]   = useState([]);
  const [selectedIssue, setSelectedIssue] = useState(null);
  const [reportOpen, setReportOpen] = useState(false);
  const [loading, setLoading] = useState(false);
  const [adminStats, setAdminStats] = useState(null);
  const [notifications, setNotifications] = useState([]);
  const [notifOpen, setNotifOpen] = useState(false);
  const [filter, setFilter]   = useState({ category: '', status: '', search: '' });
  const { toasts, show: showToast } = useToast();

  // Load user from cookie on mount
  useEffect(() => {
    api('/api/auth/me').then(d => setUser(d.user)).catch(() => {});
    loadIssues();
  }, []);

  useEffect(() => {
    if (user && view === 'admin' && ['officer','admin','superadmin'].includes(user.role)) {
      loadAdminStats();
    }
  }, [user, view]);

  useEffect(() => { loadIssues(); }, [filter]);

  async function loadIssues() {
    try {
      const params = new URLSearchParams();
      if (filter.category) params.set('category', filter.category);
      if (filter.status) params.set('status', filter.status);
      if (filter.search) params.set('search', filter.search);
      params.set('limit', '15');
      const data = await api(`/api/issues?${params}`);
      setIssues(data.issues);
    } catch (e) { console.error(e); }
  }

  async function loadAdminStats() {
    try {
      const data = await api('/api/admin/stats');
      setAdminStats(data);
    } catch (e) { console.error(e); }
  }

  async function loadNotifications() {
    if (!user) return;
    try {
      const data = await api('/api/notifications');
      setNotifications(data.notifications);
    } catch (e) {}
  }

  async function handleLogout() {
    await api('/api/auth/me', { method: 'DELETE' });
    setUser(null);
    setView('citizen');
    showToast('Logged out successfully', 'info');
  }

  async function upvoteIssue(issueId, e) {
    e.stopPropagation();
    if (!user) { setAuthOpen(true); return; }
    try {
      const data = await api(`/api/issues/${issueId}?action=upvote`, { method: 'POST' });
      setIssues(prev => prev.map(i => i.id === issueId ? { ...i, votes: data.votes } : i));
      if (selectedIssue?.id === issueId) setSelectedIssue(prev => ({ ...prev, issue: { ...prev.issue, votes: data.votes } }));
      showToast('Vote recorded!');
    } catch (e) {
      showToast(e.message === 'Already voted' ? 'Already voted on this issue' : 'Failed to vote', 'error');
    }
  }

  const isAdmin = user && ['officer','admin','superadmin'].includes(user.role);

  return (
    <>
      <Head>
        <title>NagarSeva — Smart Civic Issue Platform</title>
        <meta name="description" content="Report civic issues, track resolutions, and improve your city." />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <link rel="icon" href="/favicon.ico" />
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&family=JetBrains+Mono:wght@400;500&display=swap" rel="stylesheet" />
      </Head>

      <div style={{ fontFamily: "'Plus Jakarta Sans', sans-serif", minHeight: '100vh', background: '#F0F4FF' }}>

        {/* ─── NAVBAR ─── */}
        <Navbar
          user={user}
          view={view}
          setView={setView}
          isAdmin={isAdmin}
          onLogin={() => setAuthOpen(true)}
          onLogout={handleLogout}
          onReport={() => user ? setReportOpen(true) : setAuthOpen(true)}
          notifications={notifications}
          notifOpen={notifOpen}
          setNotifOpen={setNotifOpen}
          onNotifOpen={() => { setNotifOpen(true); loadNotifications(); }}
        />

        {/* ─── VIEWS ─── */}
        {view === 'citizen' && (
          <CitizenView
            user={user}
            issues={issues}
            filter={filter}
            setFilter={setFilter}
            onSelectIssue={async (issue) => {
              setLoading(true);
              try {
                const data = await api(`/api/issues/${issue.id}`);
                setSelectedIssue(data);
              } catch(e) { showToast('Failed to load issue', 'error'); }
              setLoading(false);
            }}
            onReport={() => user ? setReportOpen(true) : setAuthOpen(true)}
            onUpvote={upvoteIssue}
          />
        )}

        {view === 'admin' && isAdmin && (
          <AdminView
            stats={adminStats}
            issues={issues}
            user={user}
            onRefresh={() => { loadAdminStats(); loadIssues(); }}
            onSelectIssue={async (issue) => {
              setLoading(true);
              try {
                const data = await api(`/api/issues/${issue.id}`);
                setSelectedIssue(data);
              } catch(e) { showToast('Failed to load', 'error'); }
              setLoading(false);
            }}
            onUpdate={async (id, updates) => {
              try {
                await api(`/api/issues/${id}`, { method: 'PUT', body: updates });
                showToast('Issue updated!');
                loadIssues(); loadAdminStats();
                setSelectedIssue(null);
              } catch(e) { showToast(e.message, 'error'); }
            }}
            showToast={showToast}
          />
        )}

        {/* ─── MODALS ─── */}
        {authOpen && (
          <AuthModal
            onClose={() => setAuthOpen(false)}
            onSuccess={(u) => {
              setUser(u);
              setAuthOpen(false);
              showToast(`Welcome, ${u.name}! 🙏`);
            }}
            showToast={showToast}
          />
        )}

        {reportOpen && user && (
          <ReportModal
            user={user}
            onClose={() => setReportOpen(false)}
            onSuccess={(issue) => {
              setReportOpen(false);
              showToast(`✅ Complaint ${issue.ref_number} registered!`);
              loadIssues();
            }}
            showToast={showToast}
          />
        )}

        {selectedIssue && (
          <IssueDetailPanel
            data={selectedIssue}
            loading={loading}
            onClose={() => setSelectedIssue(null)}
            user={user}
            onUpvote={upvoteIssue}
            onUpdate={async (id, updates) => {
              if (!isAdmin) return;
              try {
                await api(`/api/issues/${id}`, { method: 'PUT', body: updates });
                showToast('Updated!');
                const data = await api(`/api/issues/${id}`);
                setSelectedIssue(data);
                loadIssues();
              } catch(e) { showToast(e.message, 'error'); }
            }}
          />
        )}

        {/* ─── TOAST STACK ─── */}
        <ToastStack toasts={toasts} />
      </div>
    </>
  );
}

// ─────────────────────────────────────────────────────────────────
// NAVBAR
// ─────────────────────────────────────────────────────────────────
function Navbar({ user, view, setView, isAdmin, onLogin, onLogout, onReport, onNotifOpen, notifications, notifOpen, setNotifOpen }) {
  const unread = notifications.filter(n => !n.is_read).length;
  return (
    <nav style={{
      background: 'linear-gradient(135deg,#0F2C6F 0%,#1A4FBF 100%)',
      display: 'flex', alignItems: 'center', justifyContent: 'space-between',
      padding: '0 28px', height: 62,
      position: 'sticky', top: 0, zIndex: 200,
      boxShadow: '0 2px 20px rgba(15,44,111,0.35)',
    }}>
      {/* Brand */}
      <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
        <div style={{ width: 36, height: 36, background: '#FF6B00', borderRadius: 9, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 18 }}>🏛️</div>
        <div>
          <span style={{ fontWeight: 800, fontSize: 18, color: '#FFF', letterSpacing: -0.3 }}>
            Nagar<span style={{ color: '#FCD34D' }}>Seva</span>
          </span>
          <div style={{ fontSize: 10, color: 'rgba(255,255,255,0.55)', marginTop: -1 }}>Smart Civic Platform · India 🇮🇳</div>
        </div>
      </div>

      {/* Tabs */}
      <div style={{ display: 'flex', gap: 4, background: 'rgba(255,255,255,0.12)', borderRadius: 10, padding: 4 }}>
        {[
          { id: 'citizen', label: '🏠 Citizen Portal' },
          ...(isAdmin ? [{ id: 'admin', label: '⚙️ Admin Dashboard' }] : [])
        ].map(t => (
          <button key={t.id} onClick={() => setView(t.id)} style={{
            padding: '7px 18px', borderRadius: 7, border: 'none', cursor: 'pointer',
            fontFamily: 'inherit', fontSize: 13, fontWeight: 600,
            background: view === t.id ? 'white' : 'transparent',
            color: view === t.id ? '#1A4FBF' : 'rgba(255,255,255,0.7)',
            transition: 'all 0.2s',
          }}>{t.label}</button>
        ))}
      </div>

      {/* Right */}
      <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
        <button onClick={onReport} style={{
          padding: '8px 18px', borderRadius: 8, border: 'none',
          background: '#FF6B00', color: 'white',
          fontFamily: 'inherit', fontSize: 13, fontWeight: 700, cursor: 'pointer',
        }}>+ Report Issue</button>

        {user ? (
          <>
            <button onClick={onNotifOpen} style={{
              width: 36, height: 36, borderRadius: 8, border: '1px solid rgba(255,255,255,0.2)',
              background: 'rgba(255,255,255,0.1)', color: 'white', cursor: 'pointer',
              position: 'relative', fontSize: 18, display: 'flex', alignItems: 'center', justifyContent: 'center',
            }}>
              🔔
              {unread > 0 && <span style={{
                position: 'absolute', top: -3, right: -3,
                background: '#DC2626', color: 'white', borderRadius: 10,
                fontSize: 9, fontWeight: 700, padding: '1px 5px', minWidth: 16, textAlign: 'center',
              }}>{unread}</span>}
            </button>
            <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
              <div style={{ width: 32, height: 32, borderRadius: '50%', background: '#FCD34D', display: 'flex', alignItems: 'center', justifyContent: 'center', fontWeight: 800, fontSize: 13, color: '#0F2C6F' }}>
                {user.name?.charAt(0).toUpperCase()}
              </div>
              <span style={{ color: 'rgba(255,255,255,0.9)', fontSize: 13, fontWeight: 600 }}>{user.name?.split(' ')[0]}</span>
              <button onClick={onLogout} style={{
                padding: '5px 10px', borderRadius: 6, border: '1px solid rgba(255,255,255,0.25)',
                background: 'transparent', color: 'rgba(255,255,255,0.7)',
                fontSize: 12, cursor: 'pointer', fontFamily: 'inherit',
              }}>Logout</button>
            </div>
          </>
        ) : (
          <button onClick={onLogin} style={{
            padding: '8px 18px', borderRadius: 8, border: '1.5px solid rgba(255,255,255,0.4)',
            background: 'transparent', color: 'white',
            fontFamily: 'inherit', fontSize: 13, fontWeight: 600, cursor: 'pointer',
          }}>Login / Register</button>
        )}
      </div>

      {/* Notifications dropdown */}
      {notifOpen && (
        <div onClick={() => setNotifOpen(false)} style={{
          position: 'fixed', inset: 0, zIndex: 300,
        }}>
          <div onClick={e => e.stopPropagation()} style={{
            position: 'absolute', top: 68, right: 140,
            width: 360, maxHeight: 440, background: 'white',
            borderRadius: 14, boxShadow: '0 8px 40px rgba(0,0,0,0.18)',
            overflow: 'hidden', zIndex: 301,
          }}>
            <div style={{ padding: '14px 18px', borderBottom: '1px solid #E2E8F0', fontWeight: 700, fontSize: 14 }}>
              🔔 Notifications
            </div>
            <div style={{ maxHeight: 360, overflowY: 'auto' }}>
              {notifications.length === 0 ? (
                <div style={{ padding: 32, textAlign: 'center', color: '#94A3B8', fontSize: 14 }}>No notifications yet</div>
              ) : notifications.map(n => (
                <div key={n.id} style={{
                  padding: '12px 18px', borderBottom: '1px solid #F1F5F9',
                  background: n.is_read ? 'white' : '#EEF3FF',
                }}>
                  <div style={{ fontWeight: 600, fontSize: 13, marginBottom: 3 }}>{n.title}</div>
                  <div style={{ fontSize: 12, color: '#475569' }}>{n.message}</div>
                  <div style={{ fontSize: 11, color: '#94A3B8', marginTop: 4 }}>
                    {new Date(n.created_at).toLocaleDateString('en-IN')}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </nav>
  );
}

// ─────────────────────────────────────────────────────────────────
// CITIZEN VIEW
// ─────────────────────────────────────────────────────────────────
function CitizenView({ user, issues, filter, setFilter, onSelectIssue, onReport, onUpvote }) {
  return (
    <div>
      {/* Hero */}
      <div style={{
        background: 'linear-gradient(135deg,#071A45 0%,#0F2C6F 50%,#1A4FBF 100%)',
        padding: '40px 40px 50px', position: 'relative', overflow: 'hidden',
      }}>
        <div style={{ position: 'absolute', top: -80, right: -80, width: 350, height: 350, background: 'radial-gradient(circle,rgba(255,107,0,0.18) 0%,transparent 70%)', pointerEvents: 'none' }} />
        <div style={{ maxWidth: 800, position: 'relative', zIndex: 1 }}>
          {/* India tricolor badge */}
          <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 16 }}>
            <div style={{ display: 'flex', gap: 2 }}>
              {['#FF9933','white','#128807'].map((c,i) => (
                <div key={i} style={{ width: 18, height: 5, background: c, borderRadius: 2 }} />
              ))}
            </div>
            <span style={{ fontSize: 12, color: 'rgba(255,255,255,0.7)', fontWeight: 500 }}>Serving 1.2B+ Citizens · 4800+ Cities</span>
          </div>
          <h1 style={{ fontSize: 36, fontWeight: 800, color: 'white', lineHeight: 1.2, marginBottom: 10 }}>
            Report. Track. <span style={{ color: '#FCD34D' }}>Resolve.</span>
            <br />Your City, Your Voice.
          </h1>
          <p style={{ fontSize: 15, color: 'rgba(255,255,255,0.7)', marginBottom: 28, lineHeight: 1.7, maxWidth: 600 }}>
            Report civic problems with GPS location and photo evidence. Track resolution status in real-time. Hold authorities accountable.
          </p>
          <div style={{ display: 'flex', gap: 40 }}>
            {[
              { val: '1.5 Cr+', label: 'Annual Reports', color: '#FCD34D' },
              { val: '3.2 days', label: 'Avg Resolution', color: 'white' },
              { val: '71%', label: 'Resolution Rate', color: '#4ADE80' },
            ].map(s => (
              <div key={s.label} style={{ textAlign: 'center' }}>
                <div style={{ fontSize: 26, fontWeight: 800, color: s.color, fontFamily: "'JetBrains Mono',monospace" }}>{s.val}</div>
                <div style={{ fontSize: 11, color: 'rgba(255,255,255,0.55)', textTransform: 'uppercase', letterSpacing: 0.8 }}>{s.label}</div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Search & Filter */}
      <div style={{ background: 'white', padding: '16px 32px', borderBottom: '1px solid #E2E8F0', display: 'flex', gap: 12, flexWrap: 'wrap', alignItems: 'center' }}>
        <div style={{ flex: 1, minWidth: 200, position: 'relative' }}>
          <span style={{ position: 'absolute', left: 13, top: '50%', transform: 'translateY(-50%)', color: '#94A3B8', fontSize: 16 }}>🔍</span>
          <input
            value={filter.search}
            onChange={e => setFilter(f => ({ ...f, search: e.target.value }))}
            placeholder="Search by area, issue type, or complaint ID..."
            style={{
              width: '100%', padding: '10px 14px 10px 40px',
              border: '1.5px solid #E2E8F0', borderRadius: 10,
              fontFamily: 'inherit', fontSize: 14, outline: 'none', color: '#0F172A',
            }}
          />
        </div>
        {[
          { key: 'category', placeholder: 'All Categories', options: CATEGORIES.map(c => ({ value: c.id, label: c.label })) },
          { key: 'status', placeholder: 'All Status', options: Object.entries(STATUS_CONFIG).map(([v, c]) => ({ value: v, label: c.label })) },
        ].map(({ key, placeholder, options }) => (
          <select key={key} value={filter[key]} onChange={e => setFilter(f => ({ ...f, [key]: e.target.value }))} style={{
            padding: '10px 14px', border: '1.5px solid #E2E8F0', borderRadius: 10,
            fontFamily: 'inherit', fontSize: 13, color: '#475569', background: 'white',
            outline: 'none', cursor: 'pointer',
          }}>
            <option value="">{placeholder}</option>
            {options.map(o => <option key={o.value} value={o.value}>{o.label}</option>)}
          </select>
        ))}
        {user && (
          <button onClick={() => setFilter(f => ({ ...f, my_issues: !f.my_issues }))} style={{
            padding: '10px 16px', borderRadius: 10, border: `1.5px solid ${filter.my_issues ? '#1A4FBF' : '#E2E8F0'}`,
            background: filter.my_issues ? '#EEF3FF' : 'white', color: filter.my_issues ? '#1A4FBF' : '#475569',
            fontFamily: 'inherit', fontSize: 13, fontWeight: filter.my_issues ? 600 : 400, cursor: 'pointer',
          }}>My Issues</button>
        )}
      </div>

      {/* Content Grid */}
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 380px', minHeight: 'calc(100vh - 220px)' }}>
        {/* Feed */}
        <div style={{ padding: '24px 28px' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 }}>
            <span style={{ fontWeight: 700, fontSize: 16 }}>📋 Civic Issues Feed</span>
            <button onClick={onReport} style={{
              padding: '8px 18px', borderRadius: 8, background: '#1A4FBF', color: 'white',
              border: 'none', fontFamily: 'inherit', fontSize: 13, fontWeight: 700, cursor: 'pointer',
            }}>+ Report New Issue</button>
          </div>

          {issues.length === 0 ? (
            <div style={{ textAlign: 'center', padding: '60px 0', color: '#94A3B8' }}>
              <div style={{ fontSize: 48, marginBottom: 12 }}>📭</div>
              <div style={{ fontSize: 16, fontWeight: 600 }}>No issues found</div>
              <div style={{ fontSize: 14, marginTop: 4 }}>Be the first to report a civic issue in your area</div>
              <button onClick={onReport} style={{
                marginTop: 20, padding: '10px 24px', borderRadius: 10, background: '#1A4FBF',
                color: 'white', border: 'none', fontFamily: 'inherit', fontWeight: 700, cursor: 'pointer',
              }}>Report an Issue</button>
            </div>
          ) : issues.map(issue => (
            <IssueCard key={issue.id} issue={issue} onClick={() => onSelectIssue(issue)} onUpvote={onUpvote} />
          ))}
        </div>

        {/* Map */}
        <div style={{ borderLeft: '1px solid #E2E8F0', background: 'white', position: 'sticky', top: 62, height: 'calc(100vh - 62px)', display: 'flex', flexDirection: 'column' }}>
          <div style={{ padding: '14px 18px', borderBottom: '1px solid #E2E8F0', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <span style={{ fontWeight: 700, fontSize: 14 }}>🗺️ Issue Heatmap</span>
            <span style={{ fontSize: 11, color: '#94A3B8', fontFamily: "'JetBrains Mono',monospace" }}>LIVE</span>
          </div>
          <div style={{ flex: 1, position: 'relative', overflow: 'hidden' }}>
            <MapViz issues={issues} />
          </div>
          <div style={{ padding: '12px 18px', borderTop: '1px solid #E2E8F0' }}>
            <div style={{ fontSize: 11, fontWeight: 700, color: '#94A3B8', textTransform: 'uppercase', letterSpacing: 0.8, marginBottom: 8 }}>Density</div>
            <div style={{ display: 'flex', gap: 12, flexWrap: 'wrap' }}>
              {[['#EF4444','Critical'],['#F97316','High'],['#F59E0B','Medium'],['#3B82F6','Active'],['#16A34A','Resolved']].map(([c,l]) => (
                <div key={l} style={{ display: 'flex', alignItems: 'center', gap: 5, fontSize: 11, color: '#475569' }}>
                  <div style={{ width: 8, height: 8, borderRadius: '50%', background: c }} />
                  {l}
                </div>
              ))}
            </div>
          </div>
          {/* Stats */}
          <div style={{ padding: '14px 18px', borderTop: '1px solid #E2E8F0', display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 0 }}>
            {[
              { val: issues.filter(i => i.status === 'open').length, label: 'Open', color: '#DC2626' },
              { val: issues.filter(i => i.status === 'in_progress').length, label: 'In Progress', color: '#D97706' },
              { val: issues.filter(i => i.status === 'resolved').length, label: 'Resolved', color: '#16A34A' },
            ].map((s, i) => (
              <div key={i} style={{ textAlign: 'center', borderRight: i < 2 ? '1px solid #E2E8F0' : 'none', padding: '4px 0' }}>
                <div style={{ fontSize: 22, fontWeight: 800, color: s.color, fontFamily: "'JetBrains Mono',monospace" }}>{s.val}</div>
                <div style={{ fontSize: 10, color: '#94A3B8', textTransform: 'uppercase', letterSpacing: 0.5 }}>{s.label}</div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────────
// ISSUE CARD
// ─────────────────────────────────────────────────────────────────
function IssueCard({ issue, onClick, onUpvote }) {
  const cat = CATEGORIES.find(c => c.id === issue.category) || CATEGORIES[6];
  const sev = SEVERITIES.find(s => s.id === issue.severity);
  const st = STATUS_CONFIG[issue.status] || STATUS_CONFIG.open;

  return (
    <div onClick={onClick} style={{
      background: 'white', border: '1.5px solid #E2E8F0', borderRadius: 14,
      padding: '16px 18px', marginBottom: 10, cursor: 'pointer',
      transition: 'all 0.18s', position: 'relative', overflow: 'hidden',
    }}
      onMouseEnter={e => { e.currentTarget.style.borderColor = '#1A4FBF'; e.currentTarget.style.transform = 'translateX(2px)'; e.currentTarget.style.boxShadow = '0 4px 20px rgba(26,79,191,0.08)'; }}
      onMouseLeave={e => { e.currentTarget.style.borderColor = '#E2E8F0'; e.currentTarget.style.transform = 'none'; e.currentTarget.style.boxShadow = 'none'; }}
    >
      {/* Priority left bar */}
      <div style={{ position: 'absolute', left: 0, top: 0, bottom: 0, width: 4, background: sev?.color || '#94A3B8', borderRadius: '4px 0 0 4px' }} />

      <div style={{ paddingLeft: 6 }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 8 }}>
          <div style={{ display: 'flex', gap: 6, alignItems: 'center', flexWrap: 'wrap' }}>
            <span style={{
              display: 'inline-flex', alignItems: 'center', gap: 4,
              padding: '2px 9px', borderRadius: 20, fontSize: 11, fontWeight: 600,
              background: `${cat.color}18`, color: cat.color,
            }}>{cat.icon} {cat.label}</span>
            <span style={{ padding: '2px 9px', borderRadius: 20, fontSize: 11, fontWeight: 700, background: sev?.bg, color: sev?.color }}>
              {sev?.label}
            </span>
          </div>
          <span style={{ padding: '3px 9px', borderRadius: 6, fontSize: 11, fontWeight: 700, background: st.bg, color: st.color, flexShrink: 0 }}>
            {st.label}
          </span>
        </div>

        <div style={{ fontWeight: 700, fontSize: 14, marginBottom: 5, lineHeight: 1.4 }}>{issue.title}</div>

        <div style={{ fontSize: 12, color: '#94A3B8', marginBottom: 10, display: 'flex', alignItems: 'center', gap: 4 }}>
          📍 {issue.address || issue.ward || issue.city}
        </div>

        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <div style={{ display: 'flex', gap: 12, alignItems: 'center' }}>
            <span style={{ fontSize: 11, color: '#94A3B8' }}>📅 {new Date(issue.created_at).toLocaleDateString('en-IN')}</span>
            {issue.department_name && <span style={{ fontSize: 11, color: '#94A3B8' }}>🏢 {issue.department_name}</span>}
            {issue.ref_number && <span style={{ fontSize: 11, color: '#94A3B8', fontFamily: "'JetBrains Mono',monospace" }}>{issue.ref_number}</span>}
          </div>
          <button onClick={e => onUpvote(issue.id, e)} style={{
            display: 'flex', alignItems: 'center', gap: 5, padding: '5px 12px',
            borderRadius: 8, border: '1.5px solid #E2E8F0', background: 'white',
            color: '#475569', fontSize: 12, fontWeight: 600, cursor: 'pointer',
            fontFamily: 'inherit',
          }}>▲ {issue.votes || 0}</button>
        </div>
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────────
// MAP VISUALIZATION (SVG-based)
// ─────────────────────────────────────────────────────────────────
function MapViz({ issues }) {
  const pins = issues.slice(0, 12).map((issue, i) => {
    const cat = CATEGORIES.find(c => c.id === issue.category) || CATEGORIES[6];
    const sev = SEVERITIES.find(s => s.id === issue.severity);
    // Distribute pins visually if no GPS coords
    const angle = (i / 12) * Math.PI * 2;
    const r = 80 + (i % 3) * 35;
    return {
      ...issue,
      x: issue.longitude ? ((issue.longitude - 80.8) * 3000 + 200) : (200 + r * Math.cos(angle)),
      y: issue.latitude ? ((27.0 - issue.latitude) * 3000 + 240) : (240 + r * Math.sin(angle) * 0.6),
      color: sev?.color || cat.color,
      icon: cat.icon,
    };
  });

  return (
    <svg width="100%" height="100%" viewBox="0 0 400 480" style={{ position: 'absolute', inset: 0 }}>
      {/* Map background */}
      <rect width="400" height="480" fill="#EEF3FF" />

      {/* Water */}
      <ellipse cx="320" cy="380" rx="90" ry="70" fill="#DBEAFE" stroke="#BFDBFE" strokeWidth="1" />
      <text x="300" y="382" fill="#93C5FD" fontSize="10" fontFamily="monospace">River</text>

      {/* Park */}
      <rect x="15" y="30" width="95" height="85" rx="6" fill="#DCFCE7" stroke="#BBF7D0" strokeWidth="1" />
      <text x="57" y="65" fill="#4ADE80" fontSize="10" textAnchor="middle" fontFamily="monospace">PARK</text>
      <circle cx="35" cy="80" r="10" fill="#16A34A" opacity="0.5" />
      <circle cx="60" cy="75" r="8" fill="#16A34A" opacity="0.4" />
      <circle cx="85" cy="82" r="11" fill="#16A34A" opacity="0.5" />

      {/* Roads */}
      <line x1="0" y1="140" x2="400" y2="140" stroke="#CBD5E1" strokeWidth="10" />
      <line x1="0" y1="290" x2="400" y2="290" stroke="#CBD5E1" strokeWidth="8" />
      <line x1="140" y1="0" x2="140" y2="480" stroke="#CBD5E1" strokeWidth="10" />
      <line x1="270" y1="0" x2="270" y2="350" stroke="#CBD5E1" strokeWidth="7" />
      {/* Road markings */}
      <line x1="0" y1="140" x2="400" y2="140" stroke="white" strokeWidth="1.5" strokeDasharray="15,10" />
      <line x1="140" y1="0" x2="140" y2="480" stroke="white" strokeWidth="1.5" strokeDasharray="15,10" />

      {/* City blocks */}
      {[[150,150,110,130],[280,150,110,130],[10,150,120,130],[150,300,110,80],[280,300,110,80],[10,300,120,80],[150,30,110,100]].map(([x,y,w,h],i) => (
        <rect key={i} x={x} y={y} width={w} height={h} rx="4" fill="white" stroke="#E2E8F0" strokeWidth="1" />
      ))}

      {/* Heatmap blobs */}
      {pins.slice(0,4).map((p,i) => (
        <g key={`heat-${i}`}>
          <circle cx={p.x} cy={p.y} r={38} fill={p.color} opacity="0.12" />
          <circle cx={p.x} cy={p.y} r={22} fill={p.color} opacity="0.22" />
        </g>
      ))}

      {/* Map pins */}
      {pins.map((p, i) => (
        <g key={`pin-${i}`} style={{ cursor: 'pointer' }}>
          <circle cx={p.x} cy={p.y} r={10} fill={p.color} stroke="white" strokeWidth="2.5" />
          <text x={p.x} y={p.y + 4} textAnchor="middle" fontSize="9">{p.icon}</text>
        </g>
      ))}

      {/* Labels */}
      <text x="200" y="132" fill="#64748B" fontSize="8" fontFamily="monospace" textAnchor="middle">MAIN ST</text>
      <text x="200" y="282" fill="#64748B" fontSize="8" fontFamily="monospace" textAnchor="middle">HARBOR BLVD</text>
      <text x="135" y="300" fill="#64748B" fontSize="7" fontFamily="monospace" transform="rotate(-90,135,300)">CENTRAL AVE</text>
    </svg>
  );
}

// ─────────────────────────────────────────────────────────────────
// AUTH MODAL — Login/Register with OTP
// ─────────────────────────────────────────────────────────────────
function AuthModal({ onClose, onSuccess, showToast }) {
  const [step, setStep]       = useState('email'); // email | otp | name
  const [email, setEmail]     = useState('');
  const [name, setName]       = useState('');
  const [otp, setOtp]         = useState(['','','','','','']);
  const [loading, setLoading] = useState(false);
  const [isNew, setIsNew]     = useState(false);
  const [timer, setTimer]     = useState(0);
  const inputRefs             = useRef([]);

  useEffect(() => {
    if (timer > 0) {
      const t = setTimeout(() => setTimer(v => v - 1), 1000);
      return () => clearTimeout(t);
    }
  }, [timer]);

  async function handleSendOTP(e) {
    e.preventDefault();
    if (!email) return;
    setLoading(true);
    try {
      const data = await api('/api/auth/send-otp', { method: 'POST', body: { email, name, purpose: 'login' } });
      setIsNew(data.isNewUser);
      if (data.isNewUser && !name) { setStep('name'); }
      else { setStep('otp'); setTimer(60); showToast(`OTP sent to ${email}`); }
    } catch (err) {
      showToast(err.message, 'error');
    }
    setLoading(false);
  }

  async function handleContinueName(e) {
    e.preventDefault();
    if (!name.trim()) return;
    setLoading(true);
    try {
      await api('/api/auth/send-otp', { method: 'POST', body: { email, name, purpose: 'login' } });
      setStep('otp'); setTimer(60);
      showToast(`OTP sent to ${email}`);
    } catch (err) {
      showToast(err.message, 'error');
    }
    setLoading(false);
  }

  async function handleVerifyOTP(e) {
    e.preventDefault();
    const otpStr = otp.join('');
    if (otpStr.length < 6) return;
    setLoading(true);
    try {
      const data = await api('/api/auth/verify-otp', { method: 'POST', body: { email, otp: otpStr, name } });
      onSuccess(data.user);
    } catch (err) {
      showToast(err.message, 'error');
      setOtp(['','','','','','']);
      inputRefs.current[0]?.focus();
    }
    setLoading(false);
  }

  function handleOtpInput(value, idx) {
    const newOtp = [...otp];
    newOtp[idx] = value.replace(/\D/g, '').slice(-1);
    setOtp(newOtp);
    if (value && idx < 5) inputRefs.current[idx + 1]?.focus();
  }

  function handleOtpKeyDown(e, idx) {
    if (e.key === 'Backspace' && !otp[idx] && idx > 0) {
      inputRefs.current[idx - 1]?.focus();
    }
  }

  return (
    <div onClick={onClose} style={{
      position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.55)',
      backdropFilter: 'blur(6px)', zIndex: 500,
      display: 'flex', alignItems: 'center', justifyContent: 'center',
    }}>
      <div onClick={e => e.stopPropagation()} style={{
        background: 'white', borderRadius: 20, width: 420,
        boxShadow: '0 25px 60px rgba(0,0,0,0.22)', overflow: 'hidden',
        animation: 'modalIn 0.3s ease',
      }}>
        {/* Header */}
        <div style={{ background: 'linear-gradient(135deg,#0F2C6F,#1A4FBF)', padding: '28px 28px 24px', position: 'relative' }}>
          <button onClick={onClose} style={{ position: 'absolute', top: 16, right: 16, width: 30, height: 30, borderRadius: 8, border: '1px solid rgba(255,255,255,0.25)', background: 'rgba(255,255,255,0.1)', color: 'white', cursor: 'pointer', fontSize: 16, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>✕</button>
          <div style={{ fontSize: 36, marginBottom: 8 }}>🏛️</div>
          <div style={{ fontWeight: 800, fontSize: 22, color: 'white', marginBottom: 4 }}>Welcome to NagarSeva</div>
          <div style={{ fontSize: 13, color: 'rgba(255,255,255,0.7)' }}>
            {step === 'email' && 'Sign in or create your account'}
            {step === 'name' && 'Tell us your name to continue'}
            {step === 'otp' && `Enter the 6-digit code sent to ${email}`}
          </div>
        </div>

        <div style={{ padding: '28px' }}>
          {step === 'email' && (
            <form onSubmit={handleSendOTP}>
              <div style={{ marginBottom: 20 }}>
                <label style={{ display: 'block', fontSize: 13, fontWeight: 600, marginBottom: 8 }}>Email Address <span style={{ color: '#DC2626' }}>*</span></label>
                <input
                  type="email" value={email} onChange={e => setEmail(e.target.value)}
                  placeholder="your@email.com" autoFocus required
                  style={{ width: '100%', padding: '12px 14px', border: '1.5px solid #E2E8F0', borderRadius: 10, fontFamily: 'inherit', fontSize: 15, outline: 'none' }}
                />
              </div>
              <BtnPrimary type="submit" loading={loading} style={{ width: '100%' }}>
                Continue with Email →
              </BtnPrimary>
              <p style={{ textAlign: 'center', fontSize: 12, color: '#94A3B8', marginTop: 14 }}>
                We'll send a 6-digit OTP to verify your email. No password needed.
              </p>
            </form>
          )}

          {step === 'name' && (
            <form onSubmit={handleContinueName}>
              <div style={{ background: '#EDFDF5', border: '1px solid #BBF7D0', borderRadius: 10, padding: 12, marginBottom: 18, fontSize: 13, color: '#16A34A', fontWeight: 600 }}>
                👋 Welcome! Looks like you're new here.
              </div>
              <div style={{ marginBottom: 20 }}>
                <label style={{ display: 'block', fontSize: 13, fontWeight: 600, marginBottom: 8 }}>Your Name <span style={{ color: '#DC2626' }}>*</span></label>
                <input
                  type="text" value={name} onChange={e => setName(e.target.value)}
                  placeholder="Enter your full name" autoFocus required
                  style={{ width: '100%', padding: '12px 14px', border: '1.5px solid #E2E8F0', borderRadius: 10, fontFamily: 'inherit', fontSize: 15, outline: 'none' }}
                />
              </div>
              <BtnPrimary type="submit" loading={loading} style={{ width: '100%' }}>
                Get OTP →
              </BtnPrimary>
            </form>
          )}

          {step === 'otp' && (
            <form onSubmit={handleVerifyOTP}>
              <div style={{ marginBottom: 20 }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 12 }}>
                  <label style={{ fontSize: 13, fontWeight: 600 }}>Enter 6-digit OTP</label>
                  <button type="button" onClick={() => setStep('email')} style={{ fontSize: 12, color: '#1A4FBF', background: 'none', border: 'none', cursor: 'pointer', fontFamily: 'inherit' }}>Change email</button>
                </div>
                <div style={{ display: 'flex', gap: 8, justifyContent: 'center' }}>
                  {otp.map((digit, i) => (
                    <input
                      key={i}
                      ref={el => inputRefs.current[i] = el}
                      type="text" inputMode="numeric" maxLength={1}
                      value={digit}
                      onChange={e => handleOtpInput(e.target.value, i)}
                      onKeyDown={e => handleOtpKeyDown(e, i)}
                      style={{
                        width: 48, height: 58, textAlign: 'center', fontSize: 24, fontWeight: 800,
                        border: `2px solid ${digit ? '#1A4FBF' : '#E2E8F0'}`,
                        borderRadius: 10, fontFamily: "'JetBrains Mono',monospace",
                        background: digit ? '#EEF3FF' : 'white', outline: 'none',
                        color: '#0F2C6F',
                      }}
                    />
                  ))}
                </div>
                <div style={{ textAlign: 'center', marginTop: 12, fontSize: 12, color: '#94A3B8' }}>
                  {timer > 0 ? (
                    <span>Resend OTP in <strong style={{ color: '#1A4FBF' }}>{timer}s</strong></span>
                  ) : (
                    <button type="button" onClick={handleSendOTP} style={{ color: '#1A4FBF', background: 'none', border: 'none', cursor: 'pointer', fontFamily: 'inherit', fontSize: 12, fontWeight: 600 }}>
                      Resend OTP
                    </button>
                  )}
                </div>
              </div>
              <BtnPrimary type="submit" loading={loading} style={{ width: '100%' }} disabled={otp.join('').length < 6}>
                Verify & Login ✓
              </BtnPrimary>
            </form>
          )}
        </div>
      </div>

      <style>{`@keyframes modalIn { from { opacity:0; transform:scale(0.9) translateY(16px); } to { opacity:1; transform:scale(1) translateY(0); } }`}</style>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────────
// REPORT MODAL — 4-step with GPS + Camera
// ─────────────────────────────────────────────────────────────────
function ReportModal({ user, onClose, onSuccess, showToast }) {
  const [step, setStep]         = useState(1);
  const [loading, setLoading]   = useState(false);
  const [form, setForm]         = useState({
    category: '', severity: 'medium', title: '', description: '',
    address: '', landmark: '', ward: '', city: 'Lucknow',
    latitude: null, longitude: null, location_accuracy: null,
    media: [], // base64 data URLs
  });
  const [locLoading, setLocLoading] = useState(false);
  const [locGranted, setLocGranted] = useState(false);
  const [camStream, setCamStream]   = useState(null);
  const [camActive, setCamActive]   = useState(false);
  const [nearbyIssues, setNearbyIssues] = useState([]);
  const videoRef = useRef(null);
  const canvasRef = useRef(null);
  const fileInputRef = useRef(null);

  useEffect(() => {
    return () => { if (camStream) camStream.getTracks().forEach(t => t.stop()); };
  }, [camStream]);

  async function requestLocation() {
    setLocLoading(true);
    try {
      if (!navigator.geolocation) throw new Error('Geolocation not supported');
      const pos = await new Promise((resolve, reject) =>
        navigator.geolocation.getCurrentPosition(resolve, reject, {
          enableHighAccuracy: true, timeout: 15000, maximumAge: 0
        })
      );
      const { latitude, longitude, accuracy } = pos.coords;
      setForm(f => ({ ...f, latitude, longitude, location_accuracy: Math.round(accuracy) }));
      setLocGranted(true);

      // Reverse geocode (using free API)
      try {
        const geo = await fetch(`https://nominatim.openstreetmap.org/reverse?lat=${latitude}&lon=${longitude}&format=json`);
        const geoData = await geo.json();
        const addr = geoData.display_name?.split(',').slice(0, 4).join(', ') || '';
        const ward = geoData.address?.suburb || geoData.address?.neighbourhood || '';
        const city = geoData.address?.city || geoData.address?.town || 'Lucknow';
        setForm(f => ({ ...f, address: addr, ward, city }));
      } catch {}

      // Check nearby issues
      try {
        const data = await api(`/api/issues?limit=3&search=`);
        setNearbyIssues(data.issues?.slice(0,3) || []);
      } catch {}

      showToast('Location detected successfully 📍');
    } catch (err) {
      showToast(err.code === 1 ? 'Location permission denied. Please enter address manually.' : 'Could not get location. Enter manually.', 'error');
    }
    setLocLoading(false);
  }

  async function startCamera() {
    try {
      if (!navigator.mediaDevices) throw new Error('Camera not supported');
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: 'environment', width: { ideal: 1280 }, height: { ideal: 720 } }
      });
      setCamStream(stream);
      setCamActive(true);
      setTimeout(() => { if (videoRef.current) videoRef.current.srcObject = stream; }, 100);
      showToast('Camera ready 📸');
    } catch (err) {
      showToast(err.name === 'NotAllowedError' ? 'Camera permission denied. Please upload a photo instead.' : 'Camera not available.', 'error');
    }
  }

  function capturePhoto() {
    if (!videoRef.current || !canvasRef.current) return;
    const video = videoRef.current;
    const canvas = canvasRef.current;
    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;
    canvas.getContext('2d').drawImage(video, 0, 0);
    const dataUrl = canvas.toDataURL('image/jpeg', 0.8);
    setForm(f => ({ ...f, media: [...f.media.slice(0, 4), dataUrl] }));
    stopCamera();
    showToast('Photo captured!');
  }

  function stopCamera() {
    if (camStream) camStream.getTracks().forEach(t => t.stop());
    setCamStream(null);
    setCamActive(false);
  }

  function handleFileUpload(e) {
    const files = Array.from(e.target.files);
    files.slice(0, 5 - form.media.length).forEach(file => {
      const reader = new FileReader();
      reader.onload = (ev) => {
        setForm(f => ({ ...f, media: [...f.media.slice(0, 4), ev.target.result] }));
      };
      reader.readAsDataURL(file);
    });
  }

  function removeMedia(idx) {
    setForm(f => ({ ...f, media: f.media.filter((_, i) => i !== idx) }));
  }

  async function handleSubmit() {
    if (!form.category) { showToast('Please select a category', 'error'); return; }
    if (!form.title.trim()) { showToast('Please enter a title', 'error'); return; }
    if (!form.address.trim() && !form.latitude) { showToast('Please provide a location', 'error'); return; }

    setLoading(true);
    try {
      const data = await api('/api/issues/create', { method: 'POST', body: form });
      onSuccess(data.issue);
    } catch (err) {
      showToast(err.message, 'error');
    }
    setLoading(false);
  }

  const stepTitles = ['Choose Category', 'Location & Map', 'Issue Details', 'Photo Evidence'];
  const canNext = (
    (step === 1 && form.category) ||
    (step === 2 && (form.address.trim() || form.latitude)) ||
    (step === 3 && form.title.trim()) ||
    step === 4
  );

  return (
    <div onClick={onClose} style={{
      position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.55)',
      backdropFilter: 'blur(6px)', zIndex: 400,
      display: 'flex', alignItems: 'center', justifyContent: 'center',
    }}>
      <div onClick={e => e.stopPropagation()} style={{
        background: 'white', borderRadius: 20, width: 600, maxHeight: '90vh',
        overflow: 'hidden', display: 'flex', flexDirection: 'column',
        boxShadow: '0 25px 60px rgba(0,0,0,0.22)',
        animation: 'modalIn 0.3s ease',
      }}>
        {/* Header */}
        <div style={{ padding: '20px 24px 16px', borderBottom: '1px solid #E2E8F0', display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexShrink: 0 }}>
          <div>
            <div style={{ fontWeight: 800, fontSize: 18 }}>🚨 Report a Civic Issue</div>
            <div style={{ fontSize: 12, color: '#94A3B8', marginTop: 2 }}>Logged in as {user.name}</div>
          </div>
          <button onClick={onClose} style={{ width: 32, height: 32, borderRadius: 8, border: '1px solid #E2E8F0', background: 'white', cursor: 'pointer', fontSize: 16, color: '#94A3B8', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>✕</button>
        </div>

        {/* Step bar */}
        <div style={{ padding: '14px 24px', borderBottom: '1px solid #F1F5F9', display: 'flex', gap: 0, flexShrink: 0 }}>
          {stepTitles.map((title, i) => (
            <div key={i} style={{ flex: 1, textAlign: 'center', position: 'relative' }}>
              {i < stepTitles.length - 1 && (
                <div style={{ position: 'absolute', top: 11, left: '50%', width: '100%', height: 2, background: i < step - 1 ? '#1A4FBF' : '#E2E8F0', zIndex: 0 }} />
              )}
              <div style={{
                width: 24, height: 24, borderRadius: '50%', margin: '0 auto 5px',
                background: i + 1 < step ? '#1A4FBF' : i + 1 === step ? '#FF6B00' : '#E2E8F0',
                color: i + 1 <= step ? 'white' : '#94A3B8',
                fontSize: 11, fontWeight: 700,
                display: 'flex', alignItems: 'center', justifyContent: 'center',
                position: 'relative', zIndex: 1,
              }}>
                {i + 1 < step ? '✓' : i + 1}
              </div>
              <div style={{ fontSize: 10, color: i + 1 === step ? '#FF6B00' : '#94A3B8', fontWeight: i + 1 === step ? 600 : 400 }}>{title}</div>
            </div>
          ))}
        </div>

        {/* Body */}
        <div style={{ flex: 1, overflowY: 'auto', padding: '20px 24px' }}>

          {/* STEP 1: CATEGORY */}
          {step === 1 && (
            <div>
              <div style={{ fontWeight: 700, marginBottom: 14, fontSize: 14 }}>Select Issue Category <span style={{ color: '#DC2626' }}>*</span></div>
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3,1fr)', gap: 10, marginBottom: 20 }}>
                {CATEGORIES.map(cat => (
                  <div key={cat.id} onClick={() => setForm(f => ({ ...f, category: cat.id }))} style={{
                    padding: '14px 8px', borderRadius: 12, textAlign: 'center', cursor: 'pointer',
                    border: `1.5px solid ${form.category === cat.id ? cat.color : '#E2E8F0'}`,
                    background: form.category === cat.id ? `${cat.color}12` : '#F8F9FC',
                    transition: 'all 0.18s',
                  }}>
                    <div style={{ fontSize: 28, marginBottom: 6 }}>{cat.icon}</div>
                    <div style={{ fontSize: 12, fontWeight: 600, color: form.category === cat.id ? cat.color : '#475569' }}>{cat.label}</div>
                  </div>
                ))}
              </div>

              <div style={{ fontWeight: 700, marginBottom: 10, fontSize: 14 }}>Severity Level <span style={{ color: '#DC2626' }}>*</span></div>
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4,1fr)', gap: 8 }}>
                {SEVERITIES.map(sev => (
                  <div key={sev.id} onClick={() => setForm(f => ({ ...f, severity: sev.id }))} style={{
                    padding: '10px 8px', borderRadius: 10, textAlign: 'center', cursor: 'pointer',
                    border: `1.5px solid ${form.severity === sev.id ? sev.color : '#E2E8F0'}`,
                    background: form.severity === sev.id ? sev.bg : '#F8F9FC',
                    transition: 'all 0.18s',
                  }}>
                    <div style={{ fontWeight: 700, fontSize: 13, color: form.severity === sev.id ? sev.color : '#475569' }}>{sev.label}</div>
                    <div style={{ fontSize: 10, color: '#94A3B8', marginTop: 2 }}>{sev.desc}</div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* STEP 2: LOCATION */}
          {step === 2 && (
            <div>
              {/* GPS Button */}
              <div style={{ marginBottom: 16 }}>
                <div style={{ fontWeight: 700, marginBottom: 10, fontSize: 14 }}>📍 GPS Location <span style={{ color: '#DC2626' }}>*</span></div>
                <button onClick={requestLocation} disabled={locLoading} style={{
                  width: '100%', padding: 16, borderRadius: 12,
                  border: `2px ${locGranted ? 'solid #16A34A' : 'dashed #1A4FBF'}`,
                  background: locGranted ? '#EDFDF5' : '#EEF3FF',
                  cursor: 'pointer', fontFamily: 'inherit', transition: 'all 0.2s',
                  display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 8,
                }}>
                  <div style={{ fontSize: 32 }}>{locGranted ? '✅' : locLoading ? '⏳' : '📍'}</div>
                  <div style={{ fontSize: 14, fontWeight: 700, color: locGranted ? '#16A34A' : '#1A4FBF' }}>
                    {locGranted ? `Location Tagged (±${form.location_accuracy}m accuracy)` : locLoading ? 'Getting location...' : 'Tap to Use GPS Location'}
                  </div>
                  {locGranted && form.address && <div style={{ fontSize: 12, color: '#475569', textAlign: 'center' }}>{form.address.slice(0, 80)}</div>}
                  {!locGranted && !locLoading && <div style={{ fontSize: 12, color: '#64748B' }}>Allows precise issue pinpointing on map</div>}
                </button>
              </div>

              {/* Manual address */}
              <FormField label="Street Address / Landmark" required>
                <input
                  value={form.address} onChange={e => setForm(f => ({ ...f, address: e.target.value }))}
                  placeholder="E.g. Near Gandhi Chowk, MG Road, Lucknow"
                  style={inputStyle}
                />
              </FormField>

              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
                <FormField label="Ward / Area">
                  <input value={form.ward} onChange={e => setForm(f => ({ ...f, ward: e.target.value }))} placeholder="Ward 12 / Hazratganj" style={inputStyle} />
                </FormField>
                <FormField label="City">
                  <input value={form.city} onChange={e => setForm(f => ({ ...f, city: e.target.value }))} placeholder="Lucknow" style={inputStyle} />
                </FormField>
              </div>

              {/* Nearby issues */}
              {nearbyIssues.length > 0 && (
                <div style={{ background: '#FFFBEB', border: '1.5px solid #FDE68A', borderRadius: 12, padding: 14, marginTop: 4 }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 6, fontWeight: 700, fontSize: 13, color: '#D97706', marginBottom: 10 }}>
                    🤖 AI: Similar issues found nearby — check before reporting!
                  </div>
                  {nearbyIssues.map(ni => {
                    const cat = CATEGORIES.find(c => c.id === ni.category);
                    return (
                      <div key={ni.id} style={{ background: 'white', borderRadius: 8, padding: '10px 12px', marginBottom: 6, border: '1px solid #FDE68A', cursor: 'pointer' }}>
                        <div style={{ fontWeight: 600, fontSize: 12, marginBottom: 2 }}>{cat?.icon} {ni.title}</div>
                        <div style={{ fontSize: 11, color: '#94A3B8' }}>{ni.ref_number} · {ni.votes} votes · {STATUS_CONFIG[ni.status]?.label}</div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          )}

          {/* STEP 3: DETAILS */}
          {step === 3 && (
            <div>
              <FormField label="Issue Title" required>
                <input
                  value={form.title} onChange={e => setForm(f => ({ ...f, title: e.target.value }))}
                  placeholder="Brief, clear description — e.g. Deep pothole causing tyre damage"
                  style={inputStyle} maxLength={200}
                />
              </FormField>
              <FormField label="Detailed Description">
                <textarea
                  value={form.description} onChange={e => setForm(f => ({ ...f, description: e.target.value }))}
                  placeholder="When did this start? How severe? Any safety risks? Who is affected?"
                  rows={4}
                  style={{ ...inputStyle, resize: 'vertical', lineHeight: 1.6 }}
                />
              </FormField>

              <div style={{ background: '#EEF3FF', border: '1px solid #BFDBFE', borderRadius: 10, padding: 12, fontSize: 12, color: '#1A4FBF', marginTop: 4 }}>
                📶 <strong>Low bandwidth?</strong> You can also report via SMS: send &quot;REPORT {form.category.toUpperCase()} {form.city}&quot; to <strong>1916</strong>
              </div>
            </div>
          )}

          {/* STEP 4: EVIDENCE */}
          {step === 4 && (
            <div>
              <div style={{ fontWeight: 700, marginBottom: 12, fontSize: 14 }}>📸 Photo/Video Evidence</div>

              {/* Camera view */}
              {camActive ? (
                <div style={{ marginBottom: 16 }}>
                  <video ref={videoRef} autoPlay playsInline muted style={{ width: '100%', borderRadius: 12, background: '#0F172A', maxHeight: 240 }} />
                  <canvas ref={canvasRef} style={{ display: 'none' }} />
                  <div style={{ display: 'flex', gap: 10, marginTop: 10 }}>
                    <button onClick={capturePhoto} style={{ flex: 1, padding: '12px', borderRadius: 10, background: '#1A4FBF', color: 'white', border: 'none', fontFamily: 'inherit', fontWeight: 700, cursor: 'pointer', fontSize: 14 }}>
                      📸 Capture Photo
                    </button>
                    <button onClick={stopCamera} style={{ padding: '12px 16px', borderRadius: 10, background: '#FEF2F2', color: '#DC2626', border: '1px solid #FCA5A5', fontFamily: 'inherit', cursor: 'pointer', fontWeight: 600 }}>
                      ✕ Cancel
                    </button>
                  </div>
                </div>
              ) : (
                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10, marginBottom: 14 }}>
                  <button onClick={startCamera} style={{
                    padding: '20px', borderRadius: 12, border: '2px dashed #1A4FBF',
                    background: '#EEF3FF', cursor: 'pointer', fontFamily: 'inherit',
                    display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 8,
                    color: '#1A4FBF', fontWeight: 600, fontSize: 14,
                  }}>
                    <span style={{ fontSize: 32 }}>📷</span>
                    Open Camera
                    <span style={{ fontSize: 11, color: '#64748B', fontWeight: 400 }}>Live capture</span>
                  </button>
                  <button onClick={() => fileInputRef.current?.click()} style={{
                    padding: '20px', borderRadius: 12, border: '2px dashed #E2E8F0',
                    background: '#F8F9FC', cursor: 'pointer', fontFamily: 'inherit',
                    display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 8,
                    color: '#475569', fontWeight: 600, fontSize: 14,
                  }}>
                    <span style={{ fontSize: 32 }}>📁</span>
                    Upload Files
                    <span style={{ fontSize: 11, color: '#94A3B8', fontWeight: 400 }}>PNG, JPG, MP4</span>
                  </button>
                </div>
              )}

              <input ref={fileInputRef} type="file" accept="image/*,video/*" multiple onChange={handleFileUpload} style={{ display: 'none' }} />

              {/* Media previews */}
              {form.media.length > 0 && (
                <div>
                  <div style={{ fontSize: 12, fontWeight: 600, color: '#475569', marginBottom: 8 }}>Captured ({form.media.length}/5):</div>
                  <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
                    {form.media.map((src, i) => (
                      <div key={i} style={{ position: 'relative', width: 80, height: 80 }}>
                        <img src={src} alt={`Evidence ${i+1}`} style={{ width: 80, height: 80, borderRadius: 8, objectFit: 'cover', border: '2px solid #E2E8F0' }} />
                        <button onClick={() => removeMedia(i)} style={{
                          position: 'absolute', top: -6, right: -6,
                          width: 20, height: 20, borderRadius: '50%', background: '#DC2626', color: 'white',
                          border: 'none', cursor: 'pointer', fontSize: 11, fontWeight: 700,
                          display: 'flex', alignItems: 'center', justifyContent: 'center',
                        }}>✕</button>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              <div style={{ background: '#EEF3FF', border: '1px solid #BFDBFE', borderRadius: 10, padding: 12, fontSize: 12, color: '#1A4FBF', marginTop: 14 }}>
                📶 Photos auto-compressed to 200KB for low-bandwidth upload. Evidence uploads in background.
              </div>

              <div style={{ background: '#EDFDF5', border: '1px solid #BBF7D0', borderRadius: 10, padding: 12, fontSize: 12, color: '#16A34A', marginTop: 10 }}>
                🤖 <strong>AI will automatically:</strong> Route to correct department · Assign priority score · Detect duplicates · Send SMS confirmation to your email
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div style={{ padding: '16px 24px', borderTop: '1px solid #E2E8F0', display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexShrink: 0 }}>
          <button onClick={step > 1 ? () => setStep(s => s - 1) : onClose} style={{
            padding: '10px 20px', borderRadius: 10, border: '1px solid #E2E8F0',
            background: 'white', color: '#475569', fontFamily: 'inherit', fontSize: 14, cursor: 'pointer',
          }}>
            {step > 1 ? '← Back' : 'Cancel'}
          </button>
          <div style={{ fontSize: 12, color: '#94A3B8' }}>Step {step} of 4</div>
          {step < 4 ? (
            <BtnPrimary onClick={() => setStep(s => s + 1)} disabled={!canNext}>
              Continue →
            </BtnPrimary>
          ) : (
            <BtnPrimary onClick={handleSubmit} loading={loading} style={{ background: '#16A34A' }}>
              ✓ Submit Report
            </BtnPrimary>
          )}
        </div>
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────────
// ISSUE DETAIL PANEL
// ─────────────────────────────────────────────────────────────────
function IssueDetailPanel({ data, loading, onClose, user, onUpvote, onUpdate }) {
  const { issue, media, timeline, comments } = data;
  const [updateForm, setUpdateForm] = useState({ status: '', note: '' });
  const [updating, setUpdating] = useState(false);
  const isAdmin = user && ['officer','admin','superadmin'].includes(user.role);
  const cat = CATEGORIES.find(c => c.id === issue?.category) || CATEGORIES[6];
  const sev = SEVERITIES.find(s => s.id === issue?.severity);
  const st = STATUS_CONFIG[issue?.status] || STATUS_CONFIG.open;

  const PROGRESS_MAP = { open: 10, verified: 30, assigned: 45, in_progress: 65, resolved: 100, rejected: 0, duplicate: 20 };
  const progress = PROGRESS_MAP[issue?.status] || 10;

  return (
    <div onClick={onClose} style={{ position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.4)', backdropFilter: 'blur(4px)', zIndex: 300, display: 'flex', justifyContent: 'flex-end' }}>
      <div onClick={e => e.stopPropagation()} style={{
        width: 480, height: '100vh', background: 'white', overflowY: 'auto',
        animation: 'slideIn 0.3s ease', boxShadow: '-8px 0 40px rgba(0,0,0,0.15)',
        display: 'flex', flexDirection: 'column',
      }}>
        {/* Image header */}
        <div style={{
          height: 180, background: `linear-gradient(135deg,${sev?.color || '#1A4FBF'} 0%,${cat.color} 100%)`,
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          position: 'relative', flexShrink: 0, overflow: 'hidden',
        }}>
          {media?.[0] ? (
            <img src={media[0].url} alt="Issue" style={{ width: '100%', height: '100%', objectFit: 'cover', opacity: 0.85 }} />
          ) : (
            <span style={{ fontSize: 60 }}>{cat.icon}</span>
          )}
          <button onClick={onClose} style={{
            position: 'absolute', top: 14, right: 14, width: 32, height: 32,
            borderRadius: 8, background: 'rgba(0,0,0,0.3)', border: 'none',
            color: 'white', cursor: 'pointer', fontSize: 16,
            display: 'flex', alignItems: 'center', justifyContent: 'center',
          }}>✕</button>
          <span style={{ position: 'absolute', bottom: 14, left: 14, padding: '4px 10px', borderRadius: 6, fontSize: 11, fontWeight: 700, background: st.bg, color: st.color }}>
            {st.label}
          </span>
          {media?.length > 1 && (
            <span style={{ position: 'absolute', bottom: 14, right: 14, padding: '3px 8px', borderRadius: 6, fontSize: 11, background: 'rgba(0,0,0,0.5)', color: 'white' }}>
              +{media.length - 1} photos
            </span>
          )}
        </div>

        <div style={{ padding: '20px 22px', flex: 1 }}>
          <div style={{ fontFamily: "'JetBrains Mono',monospace", fontSize: 11, color: '#94A3B8', marginBottom: 6 }}>{issue?.ref_number}</div>
          <div style={{ fontWeight: 800, fontSize: 18, marginBottom: 4, lineHeight: 1.3 }}>{issue?.title}</div>
          <div style={{ fontSize: 13, color: '#475569', display: 'flex', alignItems: 'center', gap: 4, marginBottom: 16 }}>
            📍 {issue?.address || issue?.ward || issue?.city}
          </div>

          {/* Progress bar */}
          <div style={{ marginBottom: 20 }}>
            <div style={{ height: 6, background: '#E2E8F0', borderRadius: 3, overflow: 'hidden', marginBottom: 10 }}>
              <div style={{ height: '100%', width: `${progress}%`, background: '#1A4FBF', borderRadius: 3, transition: 'width 0.8s' }} />
            </div>
            <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 10, color: '#94A3B8' }}>
              {['Reported','Verified','Assigned','Working','Resolved'].map((s,i) => (
                <span key={i} style={{ color: progress > i * 20 ? '#1A4FBF' : '#94A3B8', fontWeight: progress > i * 20 ? 600 : 400 }}>{s}</span>
              ))}
            </div>
          </div>

          {/* Stats grid */}
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10, marginBottom: 20 }}>
            {[
              { val: new Date(issue?.created_at).toLocaleDateString('en-IN'), label: 'Reported On' },
              { val: issue?.votes || 0, label: 'Community Votes' },
              { val: issue?.department_name || '—', label: 'Department' },
              { val: issue?.estimated_resolution ? new Date(issue.estimated_resolution).toLocaleDateString('en-IN') : '—', label: 'Est. Resolution' },
            ].map((s, i) => (
              <div key={i} style={{ background: '#F8F9FC', borderRadius: 10, padding: '12px 14px', border: '1px solid #E2E8F0' }}>
                <div style={{ fontWeight: 700, fontSize: 16, marginBottom: 2 }}>{s.val}</div>
                <div style={{ fontSize: 11, color: '#94A3B8' }}>{s.label}</div>
              </div>
            ))}
          </div>

          {/* Description */}
          {issue?.description && (
            <div style={{ marginBottom: 20 }}>
              <div style={{ fontSize: 11, fontWeight: 700, textTransform: 'uppercase', letterSpacing: 0.8, color: '#94A3B8', marginBottom: 8 }}>Description</div>
              <p style={{ fontSize: 13, lineHeight: 1.8, color: '#475569' }}>{issue.description}</p>
            </div>
          )}

          {/* Timeline */}
          {timeline?.length > 0 && (
            <div style={{ marginBottom: 20 }}>
              <div style={{ fontSize: 11, fontWeight: 700, textTransform: 'uppercase', letterSpacing: 0.8, color: '#94A3B8', marginBottom: 12 }}>Activity Timeline</div>
              <div style={{ position: 'relative', paddingLeft: 20 }}>
                <div style={{ position: 'absolute', left: 7, top: 8, bottom: 8, width: 1, background: '#E2E8F0' }} />
                {timeline.map((item, i) => (
                  <div key={item.id} style={{ position: 'relative', marginBottom: 16 }}>
                    <div style={{
                      position: 'absolute', left: -17, top: 4, width: 9, height: 9, borderRadius: '50%',
                      background: i === timeline.length - 1 ? '#FF6B00' : '#16A34A', border: '2px solid white',
                      boxShadow: i === timeline.length - 1 ? '0 0 0 2px rgba(255,107,0,0.2)' : 'none',
                    }} />
                    <div style={{ fontFamily: "'JetBrains Mono',monospace", fontSize: 10, color: '#94A3B8', marginBottom: 2 }}>
                      {new Date(item.created_at).toLocaleDateString('en-IN', { day:'2-digit', month:'short', year:'numeric' })}
                    </div>
                    <div style={{ fontSize: 13, color: '#475569' }}>{item.note || item.action?.replace('_', ' ')}</div>
                    {item.actor_name && <div style={{ fontSize: 11, color: '#94A3B8', marginTop: 1 }}>— {item.actor_name}</div>}
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Admin update panel */}
          {isAdmin && issue?.status !== 'resolved' && (
            <div style={{ background: '#EEF3FF', border: '1px solid #BFDBFE', borderRadius: 12, padding: 16, marginBottom: 20 }}>
              <div style={{ fontWeight: 700, fontSize: 13, marginBottom: 12, color: '#1A4FBF' }}>⚙️ Authority Actions</div>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10, marginBottom: 10 }}>
                {[
                  { val: 'verified', label: '✓ Verify' },
                  { val: 'assigned', label: '📋 Assign' },
                  { val: 'in_progress', label: '🔧 In Progress' },
                  { val: 'resolved', label: '✅ Mark Resolved' },
                  { val: 'rejected', label: '✗ Reject' },
                  { val: 'duplicate', label: '⊙ Duplicate' },
                ].map(btn => (
                  <button key={btn.val} onClick={() => setUpdateForm(f => ({ ...f, status: btn.val }))} style={{
                    padding: '8px 12px', borderRadius: 8, border: `1.5px solid ${updateForm.status === btn.val ? '#1A4FBF' : '#BFDBFE'}`,
                    background: updateForm.status === btn.val ? '#1A4FBF' : 'white',
                    color: updateForm.status === btn.val ? 'white' : '#1A4FBF',
                    fontFamily: 'inherit', fontSize: 12, fontWeight: 600, cursor: 'pointer',
                    transition: 'all 0.15s',
                  }}>{btn.label}</button>
                ))}
              </div>
              <textarea
                value={updateForm.note}
                onChange={e => setUpdateForm(f => ({ ...f, note: e.target.value }))}
                placeholder="Note for citizen (will be sent via email)..."
                rows={2}
                style={{ ...inputStyle, resize: 'none', fontSize: 13, marginBottom: 10 }}
              />
              <BtnPrimary
                onClick={async () => {
                  if (!updateForm.status) return;
                  setUpdating(true);
                  await onUpdate(issue.id, updateForm);
                  setUpdating(false);
                  setUpdateForm({ status: '', note: '' });
                }}
                loading={updating}
                disabled={!updateForm.status}
                style={{ width: '100%' }}
              >
                Update Issue →
              </BtnPrimary>
            </div>
          )}
        </div>

        {/* Actions footer */}
        <div style={{ padding: '14px 22px', borderTop: '1px solid #E2E8F0', display: 'flex', gap: 10, flexShrink: 0 }}>
          <button onClick={e => onUpvote(issue?.id, e)} style={{
            flex: 1, padding: '11px', borderRadius: 10, border: '1.5px solid #1A4FBF',
            background: '#EEF3FF', color: '#1A4FBF', fontFamily: 'inherit', fontSize: 14, fontWeight: 700, cursor: 'pointer',
          }}>👍 Upvote ({issue?.votes || 0})</button>
          <button onClick={() => navigator.share?.({ title: issue?.title, url: window.location.href }) || navigator.clipboard?.writeText(window.location.href)} style={{
            padding: '11px 18px', borderRadius: 10, border: '1.5px solid #E2E8F0',
            background: 'white', color: '#475569', fontFamily: 'inherit', fontSize: 14, cursor: 'pointer',
          }}>↗ Share</button>
        </div>
      </div>

      <style>{`@keyframes slideIn { from { transform: translateX(100%); } to { transform: translateX(0); } }`}</style>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────────
// ADMIN VIEW
// ─────────────────────────────────────────────────────────────────
function AdminView({ stats, issues, user, onRefresh, onSelectIssue, onUpdate, showToast }) {
  const s = stats?.stats;

  return (
    <div style={{ background: '#F0F4FF', minHeight: 'calc(100vh - 62px)' }}>
      {/* Top bar */}
      <div style={{ background: 'white', padding: '16px 32px', borderBottom: '1px solid #E2E8F0', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <div>
          <div style={{ fontWeight: 800, fontSize: 20 }}>⚙️ Authority Dashboard</div>
          <div style={{ fontSize: 13, color: '#94A3B8' }}>Lucknow Municipal Corporation · {new Date().toLocaleDateString('en-IN', { weekday:'long', year:'numeric', month:'long', day:'numeric' })}</div>
        </div>
        <div style={{ display: 'flex', gap: 10 }}>
          <button onClick={onRefresh} style={{ padding: '8px 16px', borderRadius: 8, border: '1px solid #E2E8F0', background: 'white', cursor: 'pointer', fontFamily: 'inherit', fontSize: 13 }}>🔄 Refresh</button>
          <button style={{ padding: '8px 16px', borderRadius: 8, background: '#1A4FBF', color: 'white', border: 'none', cursor: 'pointer', fontFamily: 'inherit', fontSize: 13, fontWeight: 600 }}>⬇ Export Report</button>
        </div>
      </div>

      {/* KPI Cards */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(5,1fr)', background: 'white', borderBottom: '1px solid #E2E8F0' }}>
        {[
          { icon: '🆕', val: s?.new_today || 0, label: 'New Today', color: '#1A4FBF', bg: '#EEF3FF' },
          { icon: '⚡', val: s?.critical_count || 0, label: 'Critical', color: '#DC2626', bg: '#FEF2F2' },
          { icon: '🔧', val: s?.in_progress_count || 0, label: 'In Progress', color: '#D97706', bg: '#FFFBEB' },
          { icon: '✅', val: s?.resolved_count || 0, label: 'Resolved', color: '#16A34A', bg: '#EDFDF5' },
          { icon: '⏱️', val: s?.avg_resolution_days ? `${s.avg_resolution_days}d` : '—', label: 'Avg Resolution', color: '#7C3AED', bg: '#F5F3FF' },
        ].map((k, i) => (
          <div key={i} style={{ padding: '18px 22px', borderRight: i < 4 ? '1px solid #E2E8F0' : 'none' }}>
            <div style={{ width: 38, height: 38, borderRadius: 10, background: k.bg, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 18, marginBottom: 10 }}>{k.icon}</div>
            <div style={{ fontSize: 28, fontWeight: 800, color: k.color, fontFamily: "'JetBrains Mono',monospace", lineHeight: 1, marginBottom: 4 }}>{k.val}</div>
            <div style={{ fontSize: 12, color: '#94A3B8' }}>{k.label}</div>
          </div>
        ))}
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 320px', padding: '20px 24px', gap: 20 }}>
        {/* Left: Issue Table */}
        <div>
          {/* AI routing banner */}
          <div style={{ background: 'linear-gradient(135deg,#EEF2FF,#F5F3FF)', border: '1px solid #C7D2FE', borderRadius: 12, padding: 16, marginBottom: 16, display: 'flex', gap: 12, alignItems: 'flex-start' }}>
            <div style={{ width: 40, height: 40, borderRadius: 10, background: 'white', border: '1px solid #C7D2FE', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 20, flexShrink: 0 }}>🤖</div>
            <div>
              <div style={{ fontWeight: 700, fontSize: 13, color: '#4338CA', marginBottom: 3 }}>AI Auto-Routing Active — 94% accuracy</div>
              <div style={{ fontSize: 12, color: '#6366F1' }}>System has auto-routed issues today. Duplicate clustering saved multiple redundant tickets this week.</div>
            </div>
          </div>

          <div style={{ background: 'white', borderRadius: 14, border: '1px solid #E2E8F0', overflow: 'hidden' }}>
            <div style={{ padding: '14px 18px', borderBottom: '1px solid #E2E8F0', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <span style={{ fontWeight: 700, fontSize: 14 }}>📋 Issue Queue</span>
              <span style={{ fontFamily: "'JetBrains Mono',monospace", fontSize: 11, color: '#94A3B8' }}>{issues.length} issues</span>
            </div>
            <div style={{ overflowX: 'auto' }}>
              <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 13 }}>
                <thead>
                  <tr style={{ background: '#F8F9FC' }}>
                    {['ID','Issue','Category','Location','Priority','Status','SLA'].map(h => (
                      <th key={h} style={{ padding: '10px 14px', textAlign: 'left', fontSize: 11, fontWeight: 700, textTransform: 'uppercase', letterSpacing: 0.7, color: '#94A3B8', borderBottom: '1px solid #E2E8F0', whiteSpace: 'nowrap' }}>{h}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {issues.map(issue => {
                    const cat = CATEGORIES.find(c => c.id === issue.category) || CATEGORIES[6];
                    const sev = SEVERITIES.find(s => s.id === issue.severity);
                    const st = STATUS_CONFIG[issue.status] || STATUS_CONFIG.open;
                    const daysOld = Math.floor((Date.now() - new Date(issue.created_at)) / 86400000);
                    const slaColor = daysOld > 5 ? '#DC2626' : daysOld > 3 ? '#D97706' : '#16A34A';
                    return (
                      <tr key={issue.id} onClick={() => onSelectIssue(issue)} style={{ cursor: 'pointer', borderBottom: '1px solid #F1F5F9' }}
                        onMouseEnter={e => e.currentTarget.style.background = '#F8F9FC'}
                        onMouseLeave={e => e.currentTarget.style.background = 'white'}>
                        <td style={{ padding: '10px 14px', fontFamily: "'JetBrains Mono',monospace", fontSize: 10, color: '#94A3B8' }}>{issue.ref_number}</td>
                        <td style={{ padding: '10px 14px', fontWeight: 600, maxWidth: 160, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{issue.title}</td>
                        <td style={{ padding: '10px 14px' }}>
                          <span style={{ display: 'inline-flex', alignItems: 'center', gap: 4, padding: '2px 8px', borderRadius: 20, fontSize: 11, background: `${cat.color}15`, color: cat.color }}>{cat.icon} {cat.label}</span>
                        </td>
                        <td style={{ padding: '10px 14px', fontSize: 12, color: '#94A3B8' }}>📍 {issue.ward || issue.city}</td>
                        <td style={{ padding: '10px 14px' }}>
                          <span style={{ padding: '3px 8px', borderRadius: 6, fontSize: 11, fontWeight: 600, background: sev?.bg, color: sev?.color }}>{sev?.label}</span>
                        </td>
                        <td style={{ padding: '10px 14px' }}>
                          <span style={{ padding: '3px 8px', borderRadius: 6, fontSize: 11, fontWeight: 700, background: st.bg, color: st.color }}>{st.label}</span>
                        </td>
                        <td style={{ padding: '10px 14px', fontWeight: 700, fontSize: 12, color: slaColor, fontFamily: "'JetBrains Mono',monospace" }}>
                          {daysOld}d
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        </div>

        {/* Right: Charts & Hotspots */}
        <div>
          {/* Category breakdown */}
          <div style={{ background: 'white', borderRadius: 14, border: '1px solid #E2E8F0', padding: 18, marginBottom: 16 }}>
            <div style={{ fontWeight: 700, fontSize: 13, marginBottom: 14 }}>📊 Issues by Category</div>
            {(stats?.categories || []).map((cat) => {
              const c = CATEGORIES.find(x => x.id === cat.category) || CATEGORIES[6];
              const maxCount = stats?.categories?.[0]?.count || 1;
              return (
                <div key={cat.category} style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 10 }}>
                  <div style={{ width: 20, textAlign: 'center', fontSize: 14 }}>{c.icon}</div>
                  <div style={{ fontSize: 12, color: '#475569', width: 80, flexShrink: 0 }}>{c.label.split(' ')[0]}</div>
                  <div style={{ flex: 1, height: 8, background: '#F1F5F9', borderRadius: 4, overflow: 'hidden' }}>
                    <div style={{ height: '100%', width: `${(cat.count / maxCount) * 100}%`, background: c.color, borderRadius: 4 }} />
                  </div>
                  <div style={{ fontSize: 11, color: '#94A3B8', fontFamily: "'JetBrains Mono',monospace", width: 24, textAlign: 'right' }}>{cat.count}</div>
                </div>
              );
            })}
          </div>

          {/* Hotspots */}
          <div style={{ background: 'white', borderRadius: 14, border: '1px solid #E2E8F0', padding: 18, marginBottom: 16 }}>
            <div style={{ fontWeight: 700, fontSize: 13, marginBottom: 14 }}>🔥 Issue Hotspots</div>
            {(stats?.hotspots || []).length === 0 ? (
              <div style={{ textAlign: 'center', color: '#94A3B8', fontSize: 13, padding: '20px 0' }}>No hotspot data yet</div>
            ) : stats.hotspots.map((h, i) => (
              <div key={i} style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '10px', background: '#F8F9FC', borderRadius: 8, marginBottom: 8 }}>
                <div style={{ fontWeight: 800, fontSize: 13, color: i === 0 ? '#DC2626' : i === 1 ? '#F97316' : '#D97706', width: 20 }}>#{i+1}</div>
                <div style={{ flex: 1 }}>
                  <div style={{ fontWeight: 600, fontSize: 13 }}>{h.ward}, {h.city}</div>
                  <div style={{ fontSize: 11, color: '#94A3B8' }}>{h.count} active issues</div>
                </div>
                <div style={{ fontFamily: "'JetBrains Mono',monospace", fontSize: 12, color: '#94A3B8' }}>{h.count}</div>
              </div>
            ))}
          </div>

          {/* SMS */}
          <div style={{ background: '#0F172A', borderRadius: 14, padding: 18 }}>
            <div style={{ fontSize: 12, fontWeight: 700, color: 'rgba(255,255,255,0.5)', textTransform: 'uppercase', letterSpacing: 0.8, marginBottom: 10 }}>📱 Low-Bandwidth Channels</div>
            <div style={{ fontFamily: "'JetBrains Mono',monospace", fontSize: 12, background: 'rgba(255,255,255,0.06)', borderRadius: 8, padding: 12, color: '#94A3B8', lineHeight: 1.8 }}>
              SMS to: <span style={{ color: '#60A5FA' }}>7788-NAGAR</span><br/>
              Format: REPORT [TYPE] [AREA]<br/>
              E.g: <span style={{ color: '#4ADE80' }}>REPORT POTHOLE GOMTINAGAR</span>
            </div>
            <div style={{ marginTop: 10, padding: '8px 12px', background: 'rgba(26,79,191,0.25)', borderRadius: 8, fontSize: 12, color: '#93C5FD' }}>
              📞 IVR: 1916 · WhatsApp: +91-9876543210
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────────
// SHARED UI COMPONENTS
// ─────────────────────────────────────────────────────────────────
function BtnPrimary({ children, loading, disabled, onClick, type = 'button', style = {} }) {
  return (
    <button
      type={type}
      onClick={onClick}
      disabled={disabled || loading}
      style={{
        padding: '11px 24px', borderRadius: 10, border: 'none',
        background: disabled || loading ? '#94A3B8' : '#1A4FBF',
        color: 'white', fontFamily: 'inherit', fontSize: 14, fontWeight: 700,
        cursor: disabled || loading ? 'not-allowed' : 'pointer',
        display: 'inline-flex', alignItems: 'center', justifyContent: 'center', gap: 8,
        transition: 'all 0.18s', ...style,
      }}
    >
      {loading && <span style={{ width: 16, height: 16, border: '2px solid rgba(255,255,255,0.3)', borderTopColor: 'white', borderRadius: '50%', display: 'inline-block', animation: 'spin 0.7s linear infinite' }} />}
      {children}
    </button>
  );
}

function FormField({ label, required, children }) {
  return (
    <div style={{ marginBottom: 16 }}>
      <label style={{ display: 'block', fontSize: 13, fontWeight: 600, marginBottom: 7, color: '#0F172A' }}>
        {label} {required && <span style={{ color: '#DC2626' }}>*</span>}
      </label>
      {children}
    </div>
  );
}

function ToastStack({ toasts }) {
  const colors = {
    success: { bg: '#0F172A', border: '#16A34A', icon: '✅' },
    error:   { bg: '#0F172A', border: '#DC2626', icon: '❌' },
    info:    { bg: '#0F172A', border: '#1A4FBF', icon: 'ℹ️' },
    warning: { bg: '#0F172A', border: '#D97706', icon: '⚠️' },
  };
  return (
    <div style={{ position: 'fixed', bottom: 24, left: '50%', transform: 'translateX(-50%)', zIndex: 999, display: 'flex', flexDirection: 'column', gap: 8, alignItems: 'center' }}>
      {toasts.map(t => {
        const cfg = colors[t.type] || colors.success;
        return (
          <div key={t.id} style={{
            background: cfg.bg, border: `1.5px solid ${cfg.border}`,
            padding: '12px 22px', borderRadius: 12,
            fontSize: 14, fontWeight: 600, color: 'white',
            display: 'flex', alignItems: 'center', gap: 10,
            boxShadow: '0 8px 30px rgba(0,0,0,0.25)',
            animation: 'slideUp 0.3s ease', whiteSpace: 'nowrap',
          }}>
            {cfg.icon} {t.message}
          </div>
        );
      })}
    </div>
  );
}

const inputStyle = {
  width: '100%', padding: '10px 14px',
  border: '1.5px solid #E2E8F0', borderRadius: 10,
  fontFamily: 'inherit', fontSize: 14, outline: 'none', color: '#0F172A',
  background: 'white',
};

// ─── Static generation (no DB needed at build time) ─────────────
export async function getStaticProps() {
  return { props: {} };
}
