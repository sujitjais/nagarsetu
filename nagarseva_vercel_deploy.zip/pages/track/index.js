// pages/track/index.js — Track complaint landing page
import { useState } from 'react';
import Head from 'next/head';
import { useRouter } from 'next/router';

export default function TrackPage() {
  const [ref, setRef] = useState('');
  const [error, setError] = useState('');
  const router = useRouter();

  function handleTrack(e) {
    e.preventDefault();
    const cleaned = ref.trim().toUpperCase();
    if (!cleaned) { setError('Please enter a complaint ID'); return; }
    if (!cleaned.startsWith('NS-') && cleaned.length < 6) {
      setError('Enter a valid complaint ID (e.g. NS-2026-1234)'); return;
    }
    router.push(`/track/${cleaned}`);
  }

  return (
    <>
      <Head>
        <title>Track Your Complaint | NagarSeva</title>
        <meta name="description" content="Track the status of your civic complaint in real-time." />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;600;700;800&family=JetBrains+Mono:wght@400;500&display=swap" rel="stylesheet" />
      </Head>
      <div style={{
        minHeight: '100vh',
        background: 'linear-gradient(135deg,#071A45 0%,#0F2C6F 50%,#1A4FBF 100%)',
        display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center',
        fontFamily: "'Plus Jakarta Sans', sans-serif", padding: '40px 20px',
      }}>
        {/* Brand */}
        <a href="/" style={{ textDecoration: 'none', display: 'flex', alignItems: 'center', gap: 12, marginBottom: 48 }}>
          <div style={{ width: 44, height: 44, background: '#FF6B00', borderRadius: 11, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 22 }}>🏛️</div>
          <span style={{ fontWeight: 800, fontSize: 22, color: 'white' }}>
            Nagar<span style={{ color: '#FCD34D' }}>Seva</span>
          </span>
        </a>

        <div style={{
          background: 'white', borderRadius: 24, padding: '40px 48px',
          width: '100%', maxWidth: 520,
          boxShadow: '0 25px 60px rgba(0,0,0,0.3)',
        }}>
          <div style={{ textAlign: 'center', marginBottom: 32 }}>
            <div style={{ fontSize: 52, marginBottom: 12 }}>🔍</div>
            <h1 style={{ fontSize: 26, fontWeight: 800, marginBottom: 8 }}>Track Your Complaint</h1>
            <p style={{ fontSize: 14, color: '#64748B', lineHeight: 1.6 }}>
              Enter your complaint reference number to see real-time status and updates
            </p>
          </div>

          <form onSubmit={handleTrack}>
            <div style={{ marginBottom: 20 }}>
              <label style={{ display: 'block', fontSize: 13, fontWeight: 600, marginBottom: 8 }}>
                Complaint Reference Number
              </label>
              <input
                type="text"
                value={ref}
                onChange={e => { setRef(e.target.value); setError(''); }}
                placeholder="NS-2026-1234"
                autoFocus
                style={{
                  width: '100%', padding: '14px 16px',
                  border: `1.5px solid ${error ? '#DC2626' : '#E2E8F0'}`,
                  borderRadius: 12, fontFamily: "'JetBrains Mono', monospace",
                  fontSize: 18, fontWeight: 600, letterSpacing: 1, outline: 'none',
                  color: '#0F172A', textTransform: 'uppercase',
                }}
              />
              {error && <div style={{ fontSize: 12, color: '#DC2626', marginTop: 6 }}>{error}</div>}
            </div>

            <button
              type="submit"
              style={{
                width: '100%', padding: '14px', borderRadius: 12, border: 'none',
                background: 'linear-gradient(135deg,#0F2C6F,#1A4FBF)',
                color: 'white', fontFamily: 'inherit', fontSize: 15, fontWeight: 700, cursor: 'pointer',
              }}
            >
              Track Status →
            </button>
          </form>

          <div style={{ marginTop: 28, padding: '16px', background: '#F8F9FC', borderRadius: 12 }}>
            <div style={{ fontSize: 12, fontWeight: 600, color: '#64748B', marginBottom: 10 }}>
              📱 Other ways to track:
            </div>
            <div style={{ fontSize: 12, color: '#94A3B8', lineHeight: 2 }}>
              SMS: <strong style={{ color: '#1A4FBF', fontFamily: 'monospace' }}>STATUS NS-2026-XXXX</strong> to <strong>7788-NAGAR</strong><br />
              IVR: Call <strong style={{ color: '#1A4FBF' }}>1916</strong> and press 2 for status
            </div>
          </div>
        </div>

        <a href="/" style={{ marginTop: 24, fontSize: 13, color: 'rgba(255,255,255,0.55)', textDecoration: 'none' }}>
          ← Back to Home
        </a>
      </div>
    </>
  );
}
