// pages/track/[ref].js — Public complaint tracking page
import { useState, useEffect } from 'react';
import Head from 'next/head';
import Link from 'next/link';

export default function TrackPage({ ref: refParam }) {
  const [data, setData]   = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [search, setSearch] = useState(refParam || '');

  useEffect(() => { if (refParam) loadIssue(refParam); else setLoading(false); }, [refParam]);

  async function loadIssue(ref) {
    setLoading(true); setError('');
    try {
      const res = await fetch(`/api/issues/${ref}`);
      const d = await res.json();
      if (!res.ok) throw new Error(d.error);
      setData(d);
    } catch (e) { setError(e.message); }
    setLoading(false);
  }

  const issue = data?.issue;
  const PROGRESS_MAP = { open: 10, verified: 30, assigned: 45, in_progress: 65, resolved: 100, rejected: 0 };
  const progress = PROGRESS_MAP[issue?.status] || 10;

  const statusColors = {
    open: '#DC2626', verified: '#1A4FBF', assigned: '#D97706',
    in_progress: '#EA580C', resolved: '#16A34A', rejected: '#94A3B8',
  };

  return (
    <>
      <Head>
        <title>{issue ? `${issue.ref_number} — NagarSeva` : 'Track Complaint — NagarSeva'}</title>
        <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;600;700;800&family=JetBrains+Mono:wght@400;500&display=swap" rel="stylesheet" />
      </Head>

      <div style={{ fontFamily: "'Plus Jakarta Sans',sans-serif", minHeight: '100vh', background: '#F0F4FF' }}>
        {/* Nav */}
        <nav style={{ background: 'linear-gradient(135deg,#0F2C6F,#1A4FBF)', padding: '16px 32px', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <Link href="/" style={{ textDecoration: 'none', fontWeight: 800, fontSize: 18, color: 'white' }}>
            🏛️ Nagar<span style={{ color: '#FCD34D' }}>Seva</span>
          </Link>
          <span style={{ color: 'rgba(255,255,255,0.7)', fontSize: 13 }}>Complaint Tracking</span>
        </nav>

        <div style={{ maxWidth: 680, margin: '40px auto', padding: '0 20px' }}>
          <h1 style={{ fontSize: 28, fontWeight: 800, marginBottom: 8 }}>Track Your Complaint</h1>
          <p style={{ color: '#475569', marginBottom: 28 }}>Enter your complaint reference number to see real-time status and updates.</p>

          {/* Search */}
          <div style={{ display: 'flex', gap: 10, marginBottom: 32 }}>
            <input
              value={search}
              onChange={e => setSearch(e.target.value.toUpperCase())}
              placeholder="E.g. NS-202610001"
              onKeyDown={e => e.key === 'Enter' && loadIssue(search)}
              style={{ flex: 1, padding: '12px 16px', border: '1.5px solid #E2E8F0', borderRadius: 10, fontFamily: 'inherit', fontSize: 15, outline: 'none', fontFamily: "'JetBrains Mono',monospace" }}
            />
            <button onClick={() => loadIssue(search)} style={{ padding: '12px 24px', background: '#1A4FBF', color: 'white', border: 'none', borderRadius: 10, fontFamily: 'inherit', fontWeight: 700, cursor: 'pointer', fontSize: 14 }}>
              Track →
            </button>
          </div>

          {loading && <div style={{ textAlign: 'center', padding: 40, color: '#94A3B8' }}>Loading...</div>}
          {error && <div style={{ background: '#FEF2F2', border: '1px solid #FCA5A5', padding: 16, borderRadius: 12, color: '#DC2626', fontWeight: 600 }}>❌ {error}</div>}

          {issue && (
            <div style={{ background: 'white', borderRadius: 16, border: '1px solid #E2E8F0', overflow: 'hidden', boxShadow: '0 4px 20px rgba(0,0,0,0.06)' }}>
              {/* Status header */}
              <div style={{ background: statusColors[issue.status] || '#1A4FBF', padding: '24px 28px', color: 'white' }}>
                <div style={{ fontFamily: "'JetBrains Mono',monospace", fontSize: 13, opacity: 0.8, marginBottom: 6 }}>{issue.ref_number}</div>
                <div style={{ fontSize: 20, fontWeight: 800, marginBottom: 8 }}>{issue.title}</div>
                <div style={{ fontSize: 14, opacity: 0.9 }}>📍 {issue.address || issue.ward}, {issue.city}</div>
              </div>

              <div style={{ padding: '24px 28px' }}>
                {/* Progress */}
                <div style={{ marginBottom: 24 }}>
                  <div style={{ height: 8, background: '#E2E8F0', borderRadius: 4, overflow: 'hidden', marginBottom: 12 }}>
                    <div style={{ height: '100%', width: `${progress}%`, background: statusColors[issue.status], borderRadius: 4, transition: 'width 1s' }} />
                  </div>
                  <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 11 }}>
                    {['Reported','Verified','Assigned','Working','Resolved'].map((s, i) => (
                      <span key={i} style={{ color: progress > i * 22 ? statusColors[issue.status] : '#94A3B8', fontWeight: progress > i * 22 ? 600 : 400 }}>{s}</span>
                    ))}
                  </div>
                </div>

                {/* Details */}
                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12, marginBottom: 24 }}>
                  {[
                    { label: 'Status', val: issue.status.replace('_',' ').toUpperCase() },
                    { label: 'Reported On', val: new Date(issue.created_at).toLocaleDateString('en-IN', { day:'2-digit', month:'short', year:'numeric' }) },
                    { label: 'Department', val: issue.department_name || 'Being assigned' },
                    { label: 'Est. Resolution', val: issue.estimated_resolution ? new Date(issue.estimated_resolution).toLocaleDateString('en-IN') : 'TBD' },
                  ].map((item, i) => (
                    <div key={i} style={{ padding: '12px 14px', background: '#F8F9FC', borderRadius: 10, border: '1px solid #E2E8F0' }}>
                      <div style={{ fontSize: 11, color: '#94A3B8', marginBottom: 4 }}>{item.label}</div>
                      <div style={{ fontWeight: 700, fontSize: 14 }}>{item.val}</div>
                    </div>
                  ))}
                </div>

                {/* Timeline */}
                {data?.timeline?.length > 0 && (
                  <div>
                    <div style={{ fontWeight: 700, fontSize: 14, marginBottom: 14 }}>Activity Timeline</div>
                    <div style={{ position: 'relative', paddingLeft: 20 }}>
                      <div style={{ position: 'absolute', left: 7, top: 8, bottom: 8, width: 1, background: '#E2E8F0' }} />
                      {data.timeline.map((item, i) => (
                        <div key={item.id} style={{ position: 'relative', marginBottom: 16 }}>
                          <div style={{ position: 'absolute', left: -17, top: 4, width: 9, height: 9, borderRadius: '50%', background: i === data.timeline.length - 1 ? '#FF6B00' : '#16A34A', border: '2px solid white' }} />
                          <div style={{ fontSize: 11, color: '#94A3B8', marginBottom: 2, fontFamily: "'JetBrains Mono',monospace" }}>
                            {new Date(item.created_at).toLocaleDateString('en-IN', { day:'2-digit', month:'short', year:'numeric', hour:'2-digit', minute:'2-digit' })}
                          </div>
                          <div style={{ fontSize: 13, color: '#475569' }}>{item.note || item.action?.replace('_',' ')}</div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                <div style={{ marginTop: 20, padding: 14, background: '#EEF3FF', borderRadius: 10, fontSize: 12, color: '#1A4FBF' }}>
                  📧 Receiving email updates at your registered email. <Link href="/" style={{ color: '#1A4FBF', fontWeight: 700 }}>→ Go to main portal</Link>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </>
  );
}

export async function getServerSideProps({ params }) {
  return { props: { ref: params?.ref || null } };
}
