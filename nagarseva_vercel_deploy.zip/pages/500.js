// pages/500.js — Custom 500 server error page
import Head from 'next/head';
import Link from 'next/link';

export default function Custom500() {
  return (
    <>
      <Head>
        <title>500 — Server Error | NagarSeva</title>
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;600;700;800&display=swap" rel="stylesheet" />
      </Head>
      <div style={{
        minHeight: '100vh',
        background: 'linear-gradient(135deg,#450707 0%,#6F0F0F 50%,#BF1A1A 100%)',
        display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center',
        fontFamily: "'Plus Jakarta Sans', sans-serif", textAlign: 'center', padding: '40px 20px',
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 48 }}>
          <div style={{ width: 44, height: 44, background: '#FF6B00', borderRadius: 11, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 22 }}>🏛️</div>
          <span style={{ fontWeight: 800, fontSize: 22, color: 'white' }}>
            Nagar<span style={{ color: '#FCD34D' }}>Seva</span>
          </span>
        </div>

        <div style={{ fontSize: 60, marginBottom: 16 }}>⚠️</div>
        <h1 style={{ fontSize: 28, fontWeight: 800, color: 'white', marginBottom: 12 }}>Server Error</h1>
        <p style={{ fontSize: 16, color: 'rgba(255,255,255,0.65)', marginBottom: 36, maxWidth: 400, lineHeight: 1.7 }}>
          Something went wrong on our end. Our team has been notified. Please try again in a few moments.
        </p>

        <Link href="/" style={{ textDecoration: 'none' }}>
          <button style={{
            padding: '13px 28px', borderRadius: 12, background: 'rgba(255,255,255,0.15)',
            border: '1.5px solid rgba(255,255,255,0.3)',
            color: 'white', fontFamily: 'inherit', fontSize: 15, fontWeight: 700, cursor: 'pointer',
          }}>
            🏠 Return Home
          </button>
        </Link>

        <div style={{ marginTop: 48, fontSize: 13, color: 'rgba(255,255,255,0.35)' }}>
          Error code: 500 · For urgent issues call <strong style={{ color: 'rgba(255,255,255,0.6)' }}>1916</strong>
        </div>
      </div>
    </>
  );
}
