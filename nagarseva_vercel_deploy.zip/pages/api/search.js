// pages/api/search.js — Unified search API
import { query } from '../../lib/db';
import { apiRateLimit } from '../../lib/rateLimit';

export default async function handler(req, res) {
  const allowed = await apiRateLimit(req, res);
  if (!allowed) return;

  if (req.method !== 'GET') return res.status(405).json({ error: 'Method not allowed' });

  const { q, type = 'issues', limit = 10 } = req.query;
  if (!q || q.trim().length < 2) return res.status(400).json({ error: 'Search query must be at least 2 characters' });

  const search = `%${q.trim()}%`;

  try {
    if (type === 'issues' || type === 'all') {
      const issues = await query(
        `SELECT
          i.id, i.ref_number, i.title, i.category, i.severity, i.status,
          i.address, i.city, i.ward, i.created_at, i.votes,
          d.name AS department_name
         FROM issues i
         LEFT JOIN departments d ON i.department_id = d.id
         WHERE i.status != 'rejected'
           AND (i.title ILIKE $1 OR i.description ILIKE $1 OR i.address ILIKE $1
                OR i.ref_number ILIKE $1 OR i.ward ILIKE $1)
         ORDER BY
           CASE WHEN i.ref_number ILIKE $1 THEN 0
                WHEN i.title ILIKE $1 THEN 1
                ELSE 2 END,
           i.created_at DESC
         LIMIT $2`,
        [search, parseInt(limit)]
      );

      return res.status(200).json({ results: issues.rows, type: 'issues', total: issues.rows.length });
    }

    return res.status(400).json({ error: 'Invalid search type' });
  } catch (err) {
    console.error('Search error:', err);
    return res.status(500).json({ error: 'Search failed' });
  }
}
