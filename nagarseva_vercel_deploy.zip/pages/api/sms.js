// pages/api/sms.js — SMS webhook for low-bandwidth issue reporting
// Integrates with MSG91, Twilio, or any SMS gateway
// SMS format: "REPORT POTHOLE HAZRATGANJ LUCKNOW"
import { query, transaction } from '../../lib/db';
import { sendOTPEmail } from '../../lib/mailer';

export const config = { api: { bodyParser: true } };

// Category keyword mapping
const CATEGORY_MAP = {
  ROAD: 'roads', ROADS: 'roads', POTHOLE: 'roads', POTHOLES: 'roads',
  WATER: 'water', PIPE: 'water', LEAK: 'water', LEAKAGE: 'water',
  LIGHT: 'lighting', LIGHTING: 'lighting', DARK: 'lighting', ELECTRICITY: 'lighting',
  DRAIN: 'drainage', DRAINAGE: 'drainage', FLOOD: 'drainage', SEWER: 'drainage',
  WASTE: 'waste', GARBAGE: 'waste', TRASH: 'waste', CLEAN: 'waste',
  PARK: 'parks', TREE: 'parks', GREEN: 'parks',
  OTHER: 'other',
};

const SEVERITY_MAP = {
  CRITICAL: 'critical', URGENT: 'critical', EMERGENCY: 'critical',
  HIGH: 'high', SERIOUS: 'high', BAD: 'high',
  LOW: 'low', MINOR: 'low',
  MEDIUM: 'medium',
};

export default async function handler(req, res) {
  // Support both GET (Twilio) and POST (MSG91/others)
  if (!['GET', 'POST'].includes(req.method)) {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  const body = req.method === 'GET' ? req.query : req.body;
  const { From, Body, sender, message } = body;

  // Normalize across providers
  const phone = From || sender;
  const text = (Body || message || '').trim().toUpperCase();

  if (!phone || !text) {
    return res.status(400).send('Invalid SMS payload');
  }

  try {
    // Parse SMS: REPORT [CATEGORY] [AREA] [CITY?] [SEVERITY?]
    const parts = text.split(/\s+/);

    if (parts[0] !== 'REPORT') {
      return sendSMSReply(res, 'Invalid format. Send: REPORT [TYPE] [AREA]\nE.g: REPORT POTHOLE HAZRATGANJ\nTypes: ROAD WATER LIGHT DRAIN WASTE PARK OTHER');
    }

    const categoryKeyword = parts[1];
    const category = CATEGORY_MAP[categoryKeyword];
    if (!category) {
      return sendSMSReply(res, `Unknown type "${categoryKeyword}". Valid: ROAD WATER LIGHT DRAIN WASTE PARK OTHER`);
    }

    const area = parts.slice(2).filter(p => !SEVERITY_MAP[p]).join(' ') || 'Location not specified';
    const severityKeyword = parts.find(p => SEVERITY_MAP[p]);
    const severity = severityKeyword ? SEVERITY_MAP[severityKeyword] : 'medium';

    // Find or create user from phone
    let user = await query('SELECT id, name FROM users WHERE phone = $1', [phone]);
    if (!user.rows.length) {
      const name = `Citizen ${phone.slice(-4)}`;
      user = await query(
        'INSERT INTO users (name, phone, role, is_verified, email) VALUES ($1, $2, $3, TRUE, $4) RETURNING id, name',
        [name, phone, 'citizen', `sms_${phone.replace(/\D/g, '')}@nagarseva.sms`]
      );
    }
    const userId = user.rows[0].id;
    const userName = user.rows[0].name;

    // Map category to department
    const deptCodeMap = {
      roads: 'ROADS', water: 'WATER', lighting: 'LIGHT',
      drainage: 'DRAIN', waste: 'WASTE', parks: 'PARKS', other: 'GENERAL'
    };
    const deptCode = deptCodeMap[category];
    const dept = await query('SELECT id FROM departments WHERE code = $1', [deptCode]);
    const departmentId = dept.rows[0]?.id || null;

    const title = `[SMS] ${categoryKeyword}: Issue reported at ${area}`;
    const priorityScore = { low: 25, medium: 50, high: 75, critical: 95 }[severity];

    // Create issue
    const result = await transaction(async (client) => {
      const issueResult = await client.query(
        `INSERT INTO issues (
          title, description, category, severity, status, priority_score,
          address, ward, city, state, reported_by, department_id, ref_number
         ) VALUES ($1,$2,$3,$4,'open',$5,$6,$6,'Lucknow','Uttar Pradesh',$7,$8,'')
         RETURNING id, ref_number, title`,
        [title, `Reported via SMS from ${phone}`, category, severity, priorityScore, area, userId, departmentId]
      );
      const issue = issueResult.rows[0];

      await client.query(
        `INSERT INTO issue_activity (issue_id, actor_id, actor_name, action, new_value, note)
         VALUES ($1,$2,$3,'created','open','Reported via SMS')`,
        [issue.id, userId, userName]
      );

      return issue;
    });

    return sendSMSReply(res, `NagarSeva: Complaint registered! ID: ${result.ref_number}\nTrack at: ${process.env.NEXT_PUBLIC_APP_URL}/track/${result.ref_number}\nThank you!`);

  } catch (err) {
    console.error('SMS webhook error:', err);
    return sendSMSReply(res, 'Sorry, we could not process your report. Please try again or call 1916.');
  }
}

function sendSMSReply(res, message) {
  // TwiML response for Twilio; plain text for others
  res.setHeader('Content-Type', 'text/xml');
  return res.status(200).send(
    `<?xml version="1.0" encoding="UTF-8"?><Response><Message>${message}</Message></Response>`
  );
}
