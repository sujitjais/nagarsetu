// pages/api/notifications.js
import { query } from '../../lib/db';
import { getUserFromRequest } from '../../lib/auth';

export default async function handler(req, res) {
  if (req.method !== 'GET') return res.status(405).json({ error: 'Method not allowed' });

  const user = getUserFromRequest(req);
  if (!user) return res.status(401).json({ error: 'Not authenticated', notifications: [] });

  if (!process.env.DATABASE_URL) {
    return res.status(200).json({ notifications: [] });
  }

  try {
    const result = await query(
      `SELECT id, title, message, is_read, created_at FROM notifications
       WHERE user_id = $1 ORDER BY created_at DESC LIMIT 20`,
      [user.id]
    );
    return res.status(200).json({ notifications: result.rows });
  } catch (err) {
    console.error('notifications error:', err.message);
    return res.status(200).json({ notifications: [] });
  }
}
