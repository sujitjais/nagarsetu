// pages/api/admin/departments.js — Department management
import { query } from '../../../lib/db';
import { requireRole } from '../../../lib/auth';
import { apiRateLimit } from '../../../lib/rateLimit';

async function handler(req, res) {
  const allowed = await apiRateLimit(req, res);
  if (!allowed) return;

  if (req.method === 'GET')    return getDepartments(req, res);
  if (req.method === 'POST')   return createDepartment(req, res);
  if (req.method === 'PUT')    return updateDepartment(req, res);
  if (req.method === 'DELETE') return deleteDepartment(req, res);
  return res.status(405).json({ error: 'Method not allowed' });
}

async function getDepartments(req, res) {
  try {
    const result = await query(
      `SELECT
        d.*,
        u.name AS head_officer_name,
        COUNT(i.id) FILTER (WHERE i.status NOT IN ('resolved','rejected')) AS open_issues,
        COUNT(i.id) FILTER (WHERE i.status = 'resolved') AS resolved_issues,
        ROUND(AVG(EXTRACT(EPOCH FROM (i.resolved_at - i.created_at))/86400.0)
          FILTER (WHERE i.status = 'resolved'), 1) AS avg_resolution_days
       FROM departments d
       LEFT JOIN users u ON d.head_officer = u.id
       LEFT JOIN issues i ON i.department_id = d.id
       GROUP BY d.id, u.name
       ORDER BY d.name`
    );
    return res.status(200).json({ departments: result.rows });
  } catch (err) {
    console.error('GET /admin/departments error:', err);
    return res.status(500).json({ error: 'Failed to fetch departments' });
  }
}

async function createDepartment(req, res) {
  const { name, code, description, email, phone, head_officer } = req.body;
  if (!name?.trim() || !code?.trim()) {
    return res.status(400).json({ error: 'Name and code are required' });
  }

  try {
    const existing = await query('SELECT id FROM departments WHERE code = $1', [code.toUpperCase()]);
    if (existing.rows.length) return res.status(409).json({ error: 'Department code already exists' });

    const result = await query(
      `INSERT INTO departments (name, code, description, email, phone, head_officer)
       VALUES ($1, $2, $3, $4, $5, $6) RETURNING *`,
      [name.trim(), code.toUpperCase(), description || null, email || null, phone || null, head_officer || null]
    );
    return res.status(201).json({ success: true, department: result.rows[0] });
  } catch (err) {
    console.error('POST /admin/departments error:', err);
    return res.status(500).json({ error: 'Failed to create department' });
  }
}

async function updateDepartment(req, res) {
  const { id, name, description, email, phone, head_officer, is_active } = req.body;
  if (!id) return res.status(400).json({ error: 'Department ID required' });

  const updates = [];
  const params = [];
  let idx = 1;

  if (name)                  { updates.push(`name = $${idx++}`);         params.push(name.trim()); }
  if (description !== undefined) { updates.push(`description = $${idx++}`); params.push(description || null); }
  if (email !== undefined)   { updates.push(`email = $${idx++}`);        params.push(email || null); }
  if (phone !== undefined)   { updates.push(`phone = $${idx++}`);        params.push(phone || null); }
  if (head_officer !== undefined) { updates.push(`head_officer = $${idx++}`); params.push(head_officer || null); }
  if (is_active !== undefined) { updates.push(`is_active = $${idx++}`);  params.push(is_active); }

  if (!updates.length) return res.status(400).json({ error: 'Nothing to update' });

  params.push(id);
  try {
    await query(`UPDATE departments SET ${updates.join(', ')} WHERE id = $${idx}`, params);
    return res.status(200).json({ success: true });
  } catch (err) {
    console.error('PUT /admin/departments error:', err);
    return res.status(500).json({ error: 'Update failed' });
  }
}

async function deleteDepartment(req, res) {
  const { id } = req.query;
  if (!id) return res.status(400).json({ error: 'Department ID required' });

  try {
    // Soft delete
    await query('UPDATE departments SET is_active = FALSE WHERE id = $1', [id]);
    return res.status(200).json({ success: true });
  } catch (err) {
    console.error('DELETE /admin/departments error:', err);
    return res.status(500).json({ error: 'Failed to deactivate department' });
  }
}

export default requireRole(['admin', 'superadmin'])(handler);
