// pages/api/admin/users.js — Admin user management
import { query } from '../../../lib/db';
import { requireRole } from '../../../lib/auth';
import { apiRateLimit } from '../../../lib/rateLimit';

async function handler(req, res) {
  const allowed = await apiRateLimit(req, res);
  if (!allowed) return;

  if (req.method === 'GET') return getUsers(req, res);
  if (req.method === 'POST') return createUser(req, res);
  if (req.method === 'PUT') return updateUser(req, res);
  if (req.method === 'DELETE') return deleteUser(req, res);
  return res.status(405).json({ error: 'Method not allowed' });
}

async function getUsers(req, res) {
  const { role, search, page = 1, limit = 20, city } = req.query;
  const offset = (parseInt(page) - 1) * parseInt(limit);

  let conditions = ['u.is_active = TRUE'];
  let params = [];
  let idx = 1;

  if (role) { conditions.push(`u.role = $${idx++}`); params.push(role); }
  if (city) { conditions.push(`u.city ILIKE $${idx++}`); params.push(`%${city}%`); }
  if (search) {
    conditions.push(`(u.name ILIKE $${idx} OR u.email ILIKE $${idx} OR u.phone ILIKE $${idx})`);
    params.push(`%${search}%`);
    idx++;
  }

  const where = conditions.length ? `WHERE ${conditions.join(' AND ')}` : '';

  try {
    const countResult = await query(`SELECT COUNT(*) FROM users u ${where}`, params);
    const total = parseInt(countResult.rows[0].count);

    params.push(parseInt(limit), offset);
    const result = await query(
      `SELECT
        u.id, u.name, u.email, u.phone, u.role,
        u.ward, u.city, u.state, u.is_verified, u.is_active,
        u.created_at, u.updated_at,
        COUNT(DISTINCT i.id) AS issues_reported,
        d.name AS department_name
       FROM users u
       LEFT JOIN issues i ON i.reported_by = u.id
       LEFT JOIN departments d ON d.head_officer = u.id
       ${where}
       GROUP BY u.id, d.name
       ORDER BY u.created_at DESC
       LIMIT $${idx++} OFFSET $${idx}`,
      params
    );

    return res.status(200).json({
      users: result.rows,
      pagination: { total, page: parseInt(page), limit: parseInt(limit), totalPages: Math.ceil(total / parseInt(limit)) },
    });
  } catch (err) {
    console.error('GET /admin/users error:', err);
    return res.status(500).json({ error: 'Failed to fetch users' });
  }
}

async function createUser(req, res) {
  const { name, email, phone, role = 'officer', ward, city = 'Lucknow', state = 'Uttar Pradesh' } = req.body;

  if (!name?.trim() || !email?.trim()) {
    return res.status(400).json({ error: 'Name and email are required' });
  }
  if (!['officer', 'admin', 'citizen'].includes(role)) {
    return res.status(400).json({ error: 'Invalid role' });
  }

  try {
    const existing = await query('SELECT id FROM users WHERE email = $1', [email.toLowerCase()]);
    if (existing.rows.length) return res.status(409).json({ error: 'Email already registered' });

    const result = await query(
      `INSERT INTO users (name, email, phone, role, ward, city, state, is_verified)
       VALUES ($1, $2, $3, $4, $5, $6, $7, TRUE) RETURNING id, name, email, role`,
      [name.trim(), email.toLowerCase(), phone || null, role, ward || null, city, state]
    );

    return res.status(201).json({ success: true, user: result.rows[0] });
  } catch (err) {
    console.error('POST /admin/users error:', err);
    return res.status(500).json({ error: 'Failed to create user' });
  }
}

async function updateUser(req, res) {
  const { id, name, role, phone, ward, city, state, is_active } = req.body;
  if (!id) return res.status(400).json({ error: 'User ID required' });

  const updates = [];
  const params = [];
  let idx = 1;

  if (name)               { updates.push(`name = $${idx++}`);       params.push(name.trim()); }
  if (role)               { updates.push(`role = $${idx++}`);       params.push(role); }
  if (phone !== undefined){ updates.push(`phone = $${idx++}`);      params.push(phone || null); }
  if (ward !== undefined) { updates.push(`ward = $${idx++}`);       params.push(ward || null); }
  if (city)               { updates.push(`city = $${idx++}`);       params.push(city); }
  if (state)              { updates.push(`state = $${idx++}`);      params.push(state); }
  if (is_active !== undefined) { updates.push(`is_active = $${idx++}`); params.push(is_active); }

  if (!updates.length) return res.status(400).json({ error: 'Nothing to update' });

  params.push(id);
  try {
    await query(`UPDATE users SET ${updates.join(', ')} WHERE id = $${idx}`, params);
    return res.status(200).json({ success: true });
  } catch (err) {
    console.error('PUT /admin/users error:', err);
    return res.status(500).json({ error: 'Update failed' });
  }
}

async function deleteUser(req, res) {
  const { id } = req.query;
  if (!id) return res.status(400).json({ error: 'User ID required' });

  try {
    // Soft delete — set is_active = false
    await query('UPDATE users SET is_active = FALSE WHERE id = $1', [id]);
    return res.status(200).json({ success: true, message: 'User deactivated' });
  } catch (err) {
    console.error('DELETE /admin/users error:', err);
    return res.status(500).json({ error: 'Failed to deactivate user' });
  }
}

export default requireRole(['admin', 'superadmin'])(handler);
