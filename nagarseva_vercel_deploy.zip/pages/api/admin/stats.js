// pages/api/admin/stats.js
import { query } from '../../../lib/db';
import { requireRole } from '../../../lib/auth';

async function handler(req, res) {
  if (req.method !== 'GET') return res.status(405).json({ error: 'Method not allowed' });

  if (!process.env.DATABASE_URL) {
    return res.status(503).json({ error: 'Database not configured', stats: {}, categories: [], hotspots: [] });
  }

  try {
    const [statsResult, catResult, hotspotResult] = await Promise.all([
      query(`SELECT
        COUNT(*) FILTER (WHERE DATE(created_at) = CURRENT_DATE) AS new_today,
        COUNT(*) FILTER (WHERE severity = 'critical' AND status NOT IN ('resolved','rejected')) AS critical_count,
        COUNT(*) FILTER (WHERE status = 'in_progress') AS in_progress_count,
        COUNT(*) FILTER (WHERE status = 'resolved') AS resolved_count,
        ROUND(AVG(EXTRACT(EPOCH FROM (resolved_at - created_at))/86400) FILTER (WHERE resolved_at IS NOT NULL), 1) AS avg_resolution_days
        FROM issues`),
      query(`SELECT category, COUNT(*) AS count FROM issues WHERE status != 'rejected' GROUP BY category ORDER BY count DESC`),
      query(`SELECT ward, city, COUNT(*) AS count FROM issues WHERE status NOT IN ('resolved','rejected') AND ward IS NOT NULL GROUP BY ward, city ORDER BY count DESC LIMIT 5`),
    ]);

    return res.status(200).json({
      stats: statsResult.rows[0],
      categories: catResult.rows,
      hotspots: hotspotResult.rows,
    });
  } catch (err) {
    console.error('admin/stats error:', err.message);
    return res.status(500).json({ error: 'Failed to fetch stats', stats: {}, categories: [], hotspots: [] });
  }
}

export default requireRole(['officer', 'admin', 'superadmin'])(handler);
