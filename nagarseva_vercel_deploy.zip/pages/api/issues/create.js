// pages/api/issues/create.js
import { query, transaction } from '../../../lib/db';
import { requireAuth } from '../../../lib/auth';
import { uploadToS3, dataURLtoBuffer } from '../../../lib/s3';

export const config = { api: { bodyParser: { sizeLimit: '20mb' } } };

async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });

  const {
    title, description, category, severity = 'medium',
    address, landmark, ward, city = 'Lucknow', state = 'Uttar Pradesh',
    latitude, longitude, location_accuracy,
    media = [],  // Array of base64 data URLs
  } = req.body;

  if (!process.env.DATABASE_URL) {
    return res.status(503).json({ error: 'Database not configured. Set DATABASE_URL in Vercel environment variables.' });
  }
  if (!title?.trim()) return res.status(400).json({ error: 'Title is required' });
  if (!category) return res.status(400).json({ error: 'Category is required' });
  if (!address?.trim() && !latitude) return res.status(400).json({ error: 'Location is required' });

  // Auto-detect department from category
  const deptMap = {
    roads: 'ROADS', water: 'WATER', lighting: 'LIGHT',
    drainage: 'DRAIN', waste: 'WASTE', parks: 'PARKS', other: 'GENERAL'
  };
  const deptCode = deptMap[category] || 'GENERAL';

  // Priority score based on severity
  const priorityMap = { low: 25, medium: 50, high: 75, critical: 95 };
  const priority_score = priorityMap[severity] || 50;

  try {
    const result = await transaction(async (client) => {
      // Get department
      const deptResult = await client.query(
        'SELECT id FROM departments WHERE code = $1', [deptCode]
      );
      const departmentId = deptResult.rows[0]?.id || null;

      // Check for duplicates nearby (within 500m)
      let duplicateOfId = null;
      if (latitude && longitude) {
        const dupCheck = await client.query(
          `SELECT id, ref_number FROM issues
           WHERE category = $1
             AND status NOT IN ('resolved', 'rejected')
             AND ABS(latitude - $2) < 0.005
             AND ABS(longitude - $3) < 0.005
             AND created_at > NOW() - INTERVAL '30 days'
           ORDER BY created_at DESC LIMIT 1`,
          [category, parseFloat(latitude), parseFloat(longitude)]
        );
        if (dupCheck.rows.length > 0) {
          duplicateOfId = dupCheck.rows[0].id;
        }
      }

      // Insert issue
      const issueResult = await client.query(
        `INSERT INTO issues (
          title, description, category, severity, status, priority_score,
          address, landmark, ward, city, state,
          latitude, longitude, location_accuracy,
          reported_by, department_id, duplicate_of, ref_number
        ) VALUES (
          $1,$2,$3,$4,'open',$5,
          $6,$7,$8,$9,$10,
          $11,$12,$13,
          $14,$15,$16, ''
        ) RETURNING *`,
        [
          title.trim(), description?.trim() || null,
          category, severity, priority_score,
          address?.trim() || null, landmark?.trim() || null,
          ward || null, city, state,
          latitude ? parseFloat(latitude) : null,
          longitude ? parseFloat(longitude) : null,
          location_accuracy ? parseFloat(location_accuracy) : null,
          req.user.id, departmentId, duplicateOfId
        ]
      );

      const issue = issueResult.rows[0];

      // Log creation activity
      await client.query(
        `INSERT INTO issue_activity (issue_id, actor_id, actor_name, action, new_value, note)
         VALUES ($1, $2, $3, 'created', $4, $5)`,
        [issue.id, req.user.id, req.user.name, 'open', 'Issue reported by citizen']
      );

      return issue;
    });

    // Upload media files (outside transaction to avoid timeout)
    if (media && media.length > 0) {
      for (const dataUrl of media.slice(0, 5)) { // Max 5 files
        try {
          const { mimeType, buffer } = dataURLtoBuffer(dataUrl);
          const { url, key } = await uploadToS3(buffer, mimeType, `issues/${result.id}`);
          await query(
            'INSERT INTO issue_media (issue_id, url, s3_key, media_type, mime_type, file_size, uploaded_by) VALUES ($1,$2,$3,$4,$5,$6,$7)',
            [result.id, url, key, mimeType.startsWith('video') ? 'video' : 'image', mimeType, buffer.length, req.user.id]
          );
        } catch (mediaErr) {
          console.error('Media upload error:', mediaErr);
          // Don't fail the whole request for media errors
        }
      }
    }

    // Create notification for user
    await query(
      `INSERT INTO notifications (user_id, issue_id, title, message, type)
       VALUES ($1, $2, $3, $4, 'success')`,
      [
        req.user.id, result.id,
        'Issue Reported Successfully!',
        `Your complaint ${result.ref_number} has been registered and routed to the relevant department.`
      ]
    );

    return res.status(201).json({
      success: true,
      issue: {
        id: result.id,
        ref_number: result.ref_number,
        title: result.title,
        status: result.status,
        category: result.category,
      },
      message: `Issue ${result.ref_number} registered successfully!`,
    });
  } catch (err) {
    console.error('CREATE issue error:', err);
    return res.status(500).json({ error: 'Failed to create issue. Please try again.' });
  }
}

export default requireAuth(handler);
