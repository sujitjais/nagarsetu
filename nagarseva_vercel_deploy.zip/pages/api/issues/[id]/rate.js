// pages/api/issues/[id]/rate.js — Citizen satisfaction rating after resolution
import { query } from '../../../../lib/db';
import { requireAuth } from '../../../../lib/auth';

async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });

  const { id } = req.query;
  const { rating, feedback } = req.body;

  if (!rating || rating < 1 || rating > 5) {
    return res.status(400).json({ error: 'Rating must be between 1 and 5' });
  }

  try {
    // Verify issue belongs to this user and is resolved
    const issueResult = await query(
      'SELECT id, status, reported_by, citizen_rating FROM issues WHERE id = $1',
      [id]
    );
    if (!issueResult.rows.length) return res.status(404).json({ error: 'Issue not found' });
    const issue = issueResult.rows[0];

    if (issue.reported_by !== req.user.id) {
      return res.status(403).json({ error: 'You can only rate your own issues' });
    }
    if (issue.status !== 'resolved') {
      return res.status(400).json({ error: 'Can only rate resolved issues' });
    }
    if (issue.citizen_rating) {
      return res.status(409).json({ error: 'Already rated this issue' });
    }

    await query(
      'UPDATE issues SET citizen_rating = $1, citizen_feedback = $2 WHERE id = $3',
      [parseInt(rating), feedback?.trim() || null, id]
    );

    // Log activity
    await query(
      `INSERT INTO issue_activity (issue_id, actor_id, actor_name, action, new_value, note)
       VALUES ($1, $2, $3, 'rated', $4, $5)`,
      [id, req.user.id, req.user.name, rating.toString(), feedback?.trim() || null]
    );

    return res.status(200).json({ success: true, message: 'Thank you for your feedback!' });
  } catch (err) {
    console.error('POST /rate error:', err);
    return res.status(500).json({ error: 'Failed to submit rating' });
  }
}

export default requireAuth(handler);
