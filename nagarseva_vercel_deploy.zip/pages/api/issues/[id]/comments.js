// pages/api/issues/[id]/comments.js — Issue comments (nested route)
import { query } from '../../../../lib/db';
import { requireAuth, getUserFromRequest } from '../../../../lib/auth';
import { apiRateLimit } from '../../../../lib/rateLimit';

export default async function handler(req, res) {
  const allowed = await apiRateLimit(req, res);
  if (!allowed) return;

  const { id } = req.query;

  if (req.method === 'GET')    return getComments(req, res, id);
  if (req.method === 'POST')   return addComment(req, res, id);
  if (req.method === 'DELETE') return deleteComment(req, res, id);
  return res.status(405).json({ error: 'Method not allowed' });
}

async function getComments(req, res, issueId) {
  try {
    const result = await query(
      `SELECT
        ic.id, ic.comment, ic.is_official, ic.created_at, ic.updated_at,
        u.id AS author_id, u.name AS author_name, u.role AS author_role
       FROM issue_comments ic
       JOIN users u ON ic.author_id = u.id
       WHERE ic.issue_id = $1 AND ic.is_hidden = FALSE
       ORDER BY ic.created_at ASC`,
      [issueId]
    );
    return res.status(200).json({ comments: result.rows });
  } catch (err) {
    console.error('GET comments error:', err);
    return res.status(500).json({ error: 'Failed to fetch comments' });
  }
}

async function addComment(req, res, issueId) {
  const user = getUserFromRequest(req);
  if (!user) return res.status(401).json({ error: 'Authentication required' });

  const { comment } = req.body;
  if (!comment?.trim()) return res.status(400).json({ error: 'Comment text is required' });
  if (comment.trim().length > 2000) return res.status(400).json({ error: 'Comment too long (max 2000 chars)' });

  const isOfficial = ['officer', 'admin', 'superadmin'].includes(user.role);

  try {
    // Verify issue exists
    const issueCheck = await query('SELECT id, reported_by FROM issues WHERE id = $1', [issueId]);
    if (!issueCheck.rows.length) return res.status(404).json({ error: 'Issue not found' });

    const result = await query(
      `INSERT INTO issue_comments (issue_id, author_id, comment, is_official)
       VALUES ($1, $2, $3, $4)
       RETURNING id, comment, is_official, created_at`,
      [issueId, user.id, comment.trim(), isOfficial]
    );

    // Log activity
    await query(
      `INSERT INTO issue_activity (issue_id, actor_id, actor_name, action, note)
       VALUES ($1, $2, $3, 'commented', $4)`,
      [issueId, user.id, user.name, isOfficial ? `[Official] ${comment.trim().slice(0, 100)}` : comment.trim().slice(0, 100)]
    );

    // Notify issue reporter if official comment
    if (isOfficial) {
      const issue = issueCheck.rows[0];
      if (issue.reported_by !== user.id) {
        await query(
          `INSERT INTO notifications (user_id, issue_id, title, message, type)
           VALUES ($1, $2, $3, $4, 'update')`,
          [
            issue.reported_by, issueId,
            'Official Update on Your Complaint',
            `An authority has commented: "${comment.trim().slice(0, 120)}${comment.trim().length > 120 ? '...' : ''}"`,
          ]
        );
      }
    }

    return res.status(201).json({
      success: true,
      comment: {
        ...result.rows[0],
        author_id: user.id,
        author_name: user.name,
        author_role: user.role,
      }
    });
  } catch (err) {
    console.error('POST comment error:', err);
    return res.status(500).json({ error: 'Failed to add comment' });
  }
}

async function deleteComment(req, res, issueId) {
  const user = getUserFromRequest(req);
  if (!user) return res.status(401).json({ error: 'Authentication required' });

  const { commentId } = req.query;
  if (!commentId) return res.status(400).json({ error: 'Comment ID required' });

  try {
    const comment = await query(
      'SELECT id, author_id FROM issue_comments WHERE id = $1 AND issue_id = $2',
      [commentId, issueId]
    );
    if (!comment.rows.length) return res.status(404).json({ error: 'Comment not found' });

    const isAdmin = ['admin', 'superadmin'].includes(user.role);
    const isOwner = comment.rows[0].author_id === user.id;

    if (!isAdmin && !isOwner) return res.status(403).json({ error: 'Cannot delete this comment' });

    // Soft delete
    await query('UPDATE issue_comments SET is_hidden = TRUE WHERE id = $1', [commentId]);
    return res.status(200).json({ success: true });
  } catch (err) {
    console.error('DELETE comment error:', err);
    return res.status(500).json({ error: 'Failed to delete comment' });
  }
}
