// pages/api/issues/[id].js
import { query } from '../../../lib/db';
import { getUserFromRequest, requireRole } from '../../../lib/auth';
import { sendStatusUpdateEmail } from '../../../lib/mailer';

export default async function handler(req, res) {
  const { id } = req.query;

  if (!process.env.DATABASE_URL) {
    return res.status(503).json({ error: 'Database not configured.' });
  }

  if (req.method === 'GET') return getIssue(req, res, id);
  if (req.method === 'PUT') return updateIssue(req, res, id);
  if (req.method === 'POST' && req.query.action === 'upvote') return upvote(req, res, id);
  return res.status(405).json({ error: 'Method not allowed' });
}

async function getIssue(req, res, id) {
  try {
    // Support lookup by ref_number OR uuid
    const isRef = id.startsWith('NS-');
    const issueResult = await query(
      `SELECT i.*,
        u.name AS reporter_name, u.email AS reporter_email,
        a.name AS assignee_name,
        d.name AS department_name, d.code AS dept_code, d.email AS dept_email
       FROM issues i
       LEFT JOIN users u ON i.reported_by = u.id
       LEFT JOIN users a ON i.assigned_to = a.id
       LEFT JOIN departments d ON i.department_id = d.id
       WHERE ${isRef ? 'i.ref_number' : 'i.id'} = $1`,
      [id]
    );

    if (!issueResult.rows.length) return res.status(404).json({ error: 'Issue not found' });
    const issue = issueResult.rows[0];

    // Increment view count
    await query('UPDATE issues SET views = views + 1 WHERE id = $1', [issue.id]);

    // Fetch media
    const mediaResult = await query(
      'SELECT id, url, media_type, mime_type FROM issue_media WHERE issue_id = $1 ORDER BY created_at',
      [issue.id]
    );

    // Fetch activity timeline
    const activityResult = await query(
      `SELECT ia.*, u.name AS actor_name
       FROM issue_activity ia
       LEFT JOIN users u ON ia.actor_id = u.id
       WHERE ia.issue_id = $1 AND ia.is_public = TRUE
       ORDER BY ia.created_at ASC`,
      [issue.id]
    );

    // Fetch comments
    const commentsResult = await query(
      `SELECT ic.*, u.name AS author_name, u.role AS author_role
       FROM issue_comments ic
       JOIN users u ON ic.author_id = u.id
       WHERE ic.issue_id = $1 AND ic.is_hidden = FALSE
       ORDER BY ic.created_at ASC`,
      [issue.id]
    );

    return res.status(200).json({
      issue,
      media: mediaResult.rows,
      timeline: activityResult.rows,
      comments: commentsResult.rows,
    });
  } catch (err) {
    console.error('GET issue error:', err);
    return res.status(500).json({ error: 'Failed to fetch issue' });
  }
}

async function updateIssue(req, res, id) {
  const user = getUserFromRequest(req);
  if (!user) return res.status(401).json({ error: 'Authentication required' });
  if (!['officer', 'admin', 'superadmin'].includes(user.role)) {
    return res.status(403).json({ error: 'Not authorized' });
  }

  const { status, assigned_to, department_id, resolution_note, estimated_resolution, note } = req.body;

  try {
    const current = await query('SELECT * FROM issues WHERE id = $1', [id]);
    if (!current.rows.length) return res.status(404).json({ error: 'Issue not found' });
    const issue = current.rows[0];

    const updates = [];
    const params = [];
    let idx = 1;

    if (status) { updates.push(`status = $${idx++}`); params.push(status); }
    if (assigned_to) { updates.push(`assigned_to = $${idx++}`); params.push(assigned_to); }
    if (department_id) { updates.push(`department_id = $${idx++}`); params.push(department_id); }
    if (resolution_note) { updates.push(`resolution_note = $${idx++}`); params.push(resolution_note); }
    if (estimated_resolution) { updates.push(`estimated_resolution = $${idx++}`); params.push(estimated_resolution); }
    if (status === 'resolved') { updates.push(`resolved_at = NOW()`); }

    if (!updates.length) return res.status(400).json({ error: 'Nothing to update' });

    params.push(id);
    await query(`UPDATE issues SET ${updates.join(', ')} WHERE id = $${idx}`, params);

    // Log activity
    if (status && status !== issue.status) {
      await query(
        `INSERT INTO issue_activity (issue_id, actor_id, actor_name, action, old_value, new_value, note)
         VALUES ($1, $2, $3, 'status_changed', $4, $5, $6)`,
        [id, user.id, user.name, issue.status, status, note || null]
      );

      // Notify citizen by email
      const reporterResult = await query(
        'SELECT email, name FROM users WHERE id = $1', [issue.reported_by]
      );
      if (reporterResult.rows.length) {
        const reporter = reporterResult.rows[0];
        await sendStatusUpdateEmail(reporter.email, reporter.name, issue.ref_number, status, resolution_note).catch(() => {});

        // In-app notification
        await query(
          `INSERT INTO notifications (user_id, issue_id, title, message, type)
           VALUES ($1, $2, $3, $4, $5)`,
          [
            issue.reported_by, issue.id,
            `Complaint ${issue.ref_number} Updated`,
            `Status changed to: ${status.replace('_', ' ').toUpperCase()}. ${resolution_note || ''}`,
            status === 'resolved' ? 'success' : 'update'
          ]
        );
      }
    }

    return res.status(200).json({ success: true, message: 'Issue updated' });
  } catch (err) {
    console.error('UPDATE issue error:', err);
    return res.status(500).json({ error: 'Update failed' });
  }
}

async function upvote(req, res, id) {
  const user = getUserFromRequest(req);
  const ip = req.headers['x-forwarded-for']?.split(',')[0] || req.socket.remoteAddress;

  try {
    if (user) {
      // Try user vote
      const existing = await query(
        'SELECT id FROM issue_votes WHERE issue_id = $1 AND user_id = $2', [id, user.id]
      );
      if (existing.rows.length) return res.status(409).json({ error: 'Already voted' });
      await query('INSERT INTO issue_votes (issue_id, user_id) VALUES ($1, $2)', [id, user.id]);
    } else {
      // Anonymous IP vote
      const existing = await query(
        'SELECT id FROM issue_votes WHERE issue_id = $1 AND ip_address = $2', [id, ip]
      );
      if (existing.rows.length) return res.status(409).json({ error: 'Already voted' });
      await query('INSERT INTO issue_votes (issue_id, ip_address) VALUES ($1, $2)', [id, ip]);
    }

    await query('UPDATE issues SET votes = votes + 1 WHERE id = $1', [id]);
    const updated = await query('SELECT votes FROM issues WHERE id = $1', [id]);

    return res.status(200).json({ success: true, votes: updated.rows[0]?.votes });
  } catch (err) {
    if (err.code === '23505') return res.status(409).json({ error: 'Already voted' });
    return res.status(500).json({ error: 'Vote failed' });
  }
}
