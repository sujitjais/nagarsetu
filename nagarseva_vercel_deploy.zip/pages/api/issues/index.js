// pages/api/issues/index.js
import { query } from '../../../lib/db';
import { getUserFromRequest } from '../../../lib/auth';

export default async function handler(req, res) {
  if (req.method !== 'GET') return res.status(405).json({ error: 'Method not allowed' });

  if (!process.env.DATABASE_URL) {
    return res.status(503).json({ error: 'Database not configured. Set DATABASE_URL in environment variables.', issues: [], pagination: { total: 0, page: 1, limit: 20, totalPages: 0 } });
  }

  const {
    status, category, severity, city, ward,
    page = 1, limit = 20,
    sort = 'created_at', order = 'DESC',
    search, my_issues,
  } = req.query;

  const user = getUserFromRequest(req);
  const offset = (parseInt(page) - 1) * parseInt(limit);

  let conditions = ["i.status != 'rejected'"];
  let params = [];
  let paramIdx = 1;

  if (status) { conditions.push(`i.status = $${paramIdx++}`); params.push(status); }
  if (category) { conditions.push(`i.category = $${paramIdx++}`); params.push(category); }
  if (severity) { conditions.push(`i.severity = $${paramIdx++}`); params.push(severity); }
  if (city) { conditions.push(`i.city ILIKE $${paramIdx++}`); params.push(`%${city}%`); }
  if (ward) { conditions.push(`i.ward ILIKE $${paramIdx++}`); params.push(`%${ward}%`); }
  if (search) {
    conditions.push(`(i.title ILIKE $${paramIdx} OR i.description ILIKE $${paramIdx} OR i.address ILIKE $${paramIdx} OR i.ref_number ILIKE $${paramIdx})`);
    params.push(`%${search}%`);
    paramIdx++;
  }
  if (my_issues === 'true' && user) {
    conditions.push(`i.reported_by = $${paramIdx++}`);
    params.push(user.id);
  }

  const where = conditions.length ? `WHERE ${conditions.join(' AND ')}` : '';
  const sortCols = { created_at: 'i.created_at', votes: 'i.votes', priority_score: 'i.priority_score' };
  const sortCol = sortCols[sort] || 'i.created_at';
  const sortOrder = order === 'ASC' ? 'ASC' : 'DESC';

  try {
    const countResult = await query(`SELECT COUNT(*) FROM issues i ${where}`, params);
    const total = parseInt(countResult.rows[0].count);
    params.push(parseInt(limit), offset);

    const result = await query(
      `SELECT
        i.id, i.ref_number, i.title, i.category, i.severity, i.status,
        i.address, i.landmark, i.ward, i.city, i.latitude, i.longitude,
        i.votes, i.priority_score, i.created_at, i.updated_at,
        i.estimated_resolution, i.resolved_at,
        u.name AS reporter_name,
        d.name AS department_name, d.code AS dept_code,
        (SELECT url FROM issue_media WHERE issue_id = i.id LIMIT 1) AS thumbnail,
        (SELECT COUNT(*) FROM issue_comments WHERE issue_id = i.id) AS comment_count
       FROM issues i
       LEFT JOIN users u ON i.reported_by = u.id
       LEFT JOIN departments d ON i.department_id = d.id
       ${where}
       ORDER BY ${sortCol} ${sortOrder}
       LIMIT $${paramIdx++} OFFSET $${paramIdx}`,
      params
    );

    return res.status(200).json({
      issues: result.rows,
      pagination: { total, page: parseInt(page), limit: parseInt(limit), totalPages: Math.ceil(total / parseInt(limit)) },
    });
  } catch (err) {
    console.error('GET /api/issues error:', err.message);
    return res.status(500).json({ error: 'Failed to fetch issues', issues: [], pagination: { total: 0 } });
  }
}
