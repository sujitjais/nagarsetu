// pages/api/auth/me.js
import { getUserFromRequest, clearAuthCookie } from '../../../lib/auth';

export default async function handler(req, res) {
  if (req.method === 'GET') {
    const user = getUserFromRequest(req);
    if (!user) return res.status(401).json({ user: null });
    return res.status(200).json({ user });
  }
  if (req.method === 'DELETE') {
    clearAuthCookie(res);
    return res.status(200).json({ success: true });
  }
  return res.status(405).json({ error: 'Method not allowed' });
}
