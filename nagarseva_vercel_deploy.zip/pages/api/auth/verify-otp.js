// pages/api/auth/verify-otp.js
import { query } from '../../../lib/db';
import { signToken, setAuthCookie } from '../../../lib/auth';

export default async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });

  const { email, otp, name } = req.body;

  if (!email || !otp) return res.status(400).json({ error: 'Email and OTP required' });

  try {
    // Find valid OTP
    const otpResult = await query(
      `SELECT * FROM otp_tokens
       WHERE email = $1 AND otp = $2 AND used = FALSE AND expires_at > NOW()
       ORDER BY created_at DESC LIMIT 1`,
      [email.toLowerCase(), otp.toString()]
    );

    if (otpResult.rows.length === 0) {
      // Increment attempts
      await query(
        'UPDATE otp_tokens SET attempts = attempts + 1 WHERE email = $1 AND used = FALSE',
        [email.toLowerCase()]
      );
      return res.status(400).json({ error: 'Invalid or expired OTP' });
    }

    // Mark OTP as used
    await query('UPDATE otp_tokens SET used = TRUE WHERE id = $1', [otpResult.rows[0].id]);

    // Get or update user
    let userResult = await query('SELECT * FROM users WHERE email = $1', [email.toLowerCase()]);

    let user;
    if (userResult.rows.length === 0) {
      // Create user
      const newUser = await query(
        'INSERT INTO users (name, email, role, is_verified) VALUES ($1, $2, $3, TRUE) RETURNING *',
        [name || email.split('@')[0], email.toLowerCase(), 'citizen']
      );
      user = newUser.rows[0];
    } else {
      user = userResult.rows[0];
      // Mark verified
      if (!user.is_verified) {
        await query('UPDATE users SET is_verified = TRUE WHERE id = $1', [user.id]);
        user.is_verified = true;
      }
      // Update name if provided
      if (name && name !== user.name) {
        await query('UPDATE users SET name = $1 WHERE id = $2', [name, user.id]);
        user.name = name;
      }
    }

    // Sign JWT
    const token = signToken({
      id: user.id,
      email: user.email,
      name: user.name,
      role: user.role,
    });

    // Set cookie
    setAuthCookie(res, token);

    return res.status(200).json({
      success: true,
      token,
      user: {
        id: user.id,
        name: user.name,
        email: user.email,
        role: user.role,
        city: user.city,
      },
    });
  } catch (err) {
    console.error('verify-otp error:', err);
    return res.status(500).json({ error: 'Verification failed. Try again.' });
  }
}
