// pages/api/auth/send-otp.js
import { query } from '../../../lib/db';
import { generateOTP } from '../../../lib/auth';
import { sendOTPEmail } from '../../../lib/mailer';
import { authRateLimit } from '../../../lib/rateLimit';

export default async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });

  if (!process.env.DATABASE_URL) {
    return res.status(503).json({ error: 'Database not configured. Set DATABASE_URL in Vercel environment variables.' });
  }

  const allowed = await authRateLimit(req, res);
  if (!allowed) return;

  const { email, name, purpose = 'login' } = req.body;
  if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
    return res.status(400).json({ error: 'Valid email required' });
  }

  try {
    const userResult = await query('SELECT id, name, is_verified FROM users WHERE email = $1', [email.toLowerCase()]);
    const userExists = userResult.rows.length > 0;
    let displayName = name || (userExists ? userResult.rows[0].name : 'Citizen');

    if (purpose === 'login' && !userExists) {
      await query(
        'INSERT INTO users (name, email, role, is_verified) VALUES ($1, $2, $3, $4)',
        [displayName || email.split('@')[0], email.toLowerCase(), 'citizen', false]
      );
    }

    await query(
      'UPDATE otp_tokens SET used = TRUE WHERE email = $1 AND purpose = $2 AND used = FALSE',
      [email.toLowerCase(), purpose]
    );

    const otp = generateOTP();
    const expiryMinutes = parseInt(process.env.OTP_EXPIRY_MINUTES || '10');
    await query(
      'INSERT INTO otp_tokens (email, otp, purpose, expires_at) VALUES ($1, $2, $3, NOW() + $4::interval)',
      [email.toLowerCase(), otp, purpose, `${expiryMinutes} minutes`]
    );

    await sendOTPEmail(email, otp, displayName);

    return res.status(200).json({ success: true, message: `OTP sent to ${email}`, isNewUser: !userExists });
  } catch (err) {
    console.error('send-otp error:', err.message);
    return res.status(500).json({ error: 'Failed to send OTP. Please try again.' });
  }
}
