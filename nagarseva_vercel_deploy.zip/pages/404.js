// pages/404.js — Custom 404 page
import Head from 'next/head';
import Link from 'next/link';

export default function Custom404() {
  return (
    <>
      <Head>
        <title>404 — Page Not Found | NagarSeva</title>
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;600;700;800&display=swap" rel="stylesheet" />
      </Head>
      <div style={{
        minHeight: '100vh',
        background: 'linear-gradient(135deg,#071A45 0%,#0F2C6F 50%,#1A4FBF 100%)',
        display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center',
        fontFamily: "'Plus Jakarta Sans', sans-serif", textAlign: 'center', padding: '40px 20px',
      }}>
        {/* Decorative circles */}
        <div style={{ position: 'absolute', top: 80, left: 80, width: 200, height: 200, borderRadius: '50%', background: 'rgba(255,107,0,0.08)', pointerEvents: 'none' }} />
        <div style={{ position: 'absolute', bottom: 60, right: 100, width: 280, height: 280, borderRadius: '50%', background: 'rgba(26,79,191,0.2)', pointerEvents: 'none' }} />

        {/* Brand */}
        <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 48, position: 'relative', zIndex: 1 }}>
          <div style={{ width: 44, height: 44, background: '#FF6B00', borderRadius: 11, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 22 }}>🏛️</div>
          <span style={{ fontWeight: 800, fontSize: 22, color: 'white' }}>
            Nagar<span style={{ color: '#FCD34D' }}>Seva</span>
          </span>
        </div>

        {/* 404 */}
        <div style={{ fontSize: 120, fontWeight: 900, color: 'rgba(255,255,255,0.06)', lineHeight: 1, userSelect: 'none', position: 'relative', zIndex: 1, letterSpacing: -4 }}>404</div>

        <div style={{ marginTop: -20, position: 'relative', zIndex: 2 }}>
          <div style={{ fontSize: 60, marginBottom: 16 }}>🚧</div>
          <h1 style={{ fontSize: 28, fontWeight: 800, color: 'white', marginBottom: 12 }}>
            Page Not Found
          </h1>
          <p style={{ fontSize: 16, color: 'rgba(255,255,255,0.65)', marginBottom: 36, maxWidth: 420, lineHeight: 1.7 }}>
            Looks like this road leads nowhere. The page you're looking for may have been moved, removed, or never existed.
          </p>

          <div style={{ display: 'flex', gap: 14, justifyContent: 'center', flexWrap: 'wrap' }}>
            <Link href="/" style={{ textDecoration: 'none' }}>
              <button style={{
                padding: '13px 28px', borderRadius: 12, background: '#FF6B00', border: 'none',
                color: 'white', fontFamily: 'inherit', fontSize: 15, fontWeight: 700, cursor: 'pointer',
              }}>
                🏠 Go to Home
              </button>
            </Link>
            <Link href="/track" style={{ textDecoration: 'none' }}>
              <button style={{
                padding: '13px 28px', borderRadius: 12, background: 'rgba(255,255,255,0.1)',
                border: '1.5px solid rgba(255,255,255,0.25)',
                color: 'white', fontFamily: 'inherit', fontSize: 15, fontWeight: 600, cursor: 'pointer',
              }}>
                🔍 Track My Complaint
              </button>
            </Link>
          </div>
        </div>

        <div style={{ marginTop: 64, fontSize: 13, color: 'rgba(255,255,255,0.35)', position: 'relative', zIndex: 1 }}>
          Need help? Call <strong style={{ color: 'rgba(255,255,255,0.6)' }}>1916</strong> or SMS <strong style={{ color: 'rgba(255,255,255,0.6)' }}>7788-NAGAR</strong>
        </div>
      </div>
    </>
  );
}
